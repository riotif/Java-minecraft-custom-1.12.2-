function main(c)
{
    //Player vars...
    var s = c.getSubject();
    var states = c.getSubject().getStates();
    var skin = states.getString("skin");
    var slim_type = states.getString("slim_type");
    var suit_skin;
    
    if (slim_type == "alex")
    {
        suit_skin = "b.a:image/skins/alex_suit.png";
    }
    else
    {
        suit_skin = "b.a:image/skins/steve_suit.png";
        states.setString("slim_type", "fred");
    }
    
    //Create UI...
    var ui = mappet.createUI(c, "handler").background();
    var layout = ui.layout();
        layout.getCurrent().rxy(0.5, 0.5).wh(300, 300).anchor(0.5);
    //MORPH
    var m = mappet.createMorph("{Animation:{Interp:21,Animates:1b},Skin:[{Path:\""+ skin +"\"},{Path:\"blockbuster:textures/entity/skin_masks/bodywear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_legwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_legwear.png\",Erase:1b},{Path:\""+suit_skin+"\"}],CustomPose:{Size:[0.6f,1.8f,0.6f],Poses:{right_arm:{P:[-6.0f,-2.0f,0.0f]},left_leg:{P:[2.0f,-12.0f,0.0f]},right_armwear:{P:[0.0f,-4.0f,0.0f]},outer:{P:[0.0f,4.0f,0.0f]},left_legwear:{P:[0.0f,-6.0f,0.0f]},body:{P:[0.0f,8.0f,0.0f]},bodywear:{P:[0.0f,-6.0f,0.0f]},head:{P:[0.0f,8.0f,0.0f]},left_arm:{P:[6.0f,-2.0f,0.0f]},right_leg:{P:[-2.0f,-12.0f,0.0f]},right_legwear:{P:[0.0f,-6.0f,0.0f]},anchor:{P:[0.0f,16.0f,0.0f],C:16777215},left_armwear:{P:[0.0f,-4.0f,0.0f]}}},Settings:{Hands:1b},Name:\"blockbuster."+ slim_type +"\"}");
    var char = layout.morph(m).id("char");
    char.rxy(0.5, 0.45).wh(100, 200).anchor(0.5).position(0.027, 0.967, 0.019).rotation(0, 35).distance(2.5).fov(50).enabled(false);
    
    
    //UI elements...
    var textbox = layout.textbox().id("textbox").tooltip("\u0421\u0441\u044b\u043b\u043a\u0430 \u043d\u0430 \u0441\u043a\u0438\u043d:").id("textbox").maxLength(999);
    var apply = layout.button("\u041f\u0440\u0438\u043c\u0435\u043d\u0438\u0442\u044c").id("skin_apply");
    var change = layout.button("\u0422\u0438\u043f.").id("change").tooltip("Steave/Alex")
    var exit = layout.button("<").id("exit").tooltip("Выйти");
    var text = layout.label("\u0423\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c \u0441\u043a\u0438\u043d \u043f\u043e \u0441\u0441\u044b\u043b\u043a\u0435:").id("text");
    
    //UE elements rendering...
    text.rxy(0.5, 0.1).wh(160, 20).anchor(0.5).labelAnchor(0.5);
    textbox.rxy(0.5, 0.83).wh(160, 20).anchor(0.5);
    change.rxy(0.278, 0.9).wh(26, 20).anchor(0.5);
    apply.rxy(0.5, 0.9).wh(106, 20).anchor(0.5);
    exit.rxy(0.725, 0.9).wh(26, 20).anchor(0.5);
    
    
    //UI elements after rendering...
    s.openUI(ui);
}

function handler(c)
{
    //Player vars...
    var s = c.getSubject();
    var states = c.getSubject().getStates();
    //UI elements...
    var uiContext = c.getSubject().getUIContext();
    var data = uiContext.getData();
    
    var slim_type = states.getString("slim_type");
    var suit_skin;
    
    if (uiContext.getLast() === "change")
    {
        if (slim_type == "fred")
        {
          states.setString("slim_type", "alex");
          var skin = states.getString("skin");
          var slim = states.getString("slim_type");
          suit_skin = "b.a:image/skins/alex_suit.png";
          var m_new = mappet.createMorph("{Animation:{Interp:21,Animates:1b},Skin:[{Path:\""+ skin +"\"},{Path:\"blockbuster:textures/entity/skin_masks/bodywear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_legwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_legwear.png\",Erase:1b},{Path:\""+suit_skin+"\"}],CustomPose:{Size:[0.6f,1.8f,0.6f],Poses:{right_arm:{P:[-6.0f,-2.0f,0.0f]},left_leg:{P:[2.0f,-12.0f,0.0f]},right_armwear:{P:[0.0f,-4.0f,0.0f]},outer:{P:[0.0f,4.0f,0.0f]},left_legwear:{P:[0.0f,-6.0f,0.0f]},body:{P:[0.0f,8.0f,0.0f]},bodywear:{P:[0.0f,-6.0f,0.0f]},head:{P:[0.0f,8.0f,0.0f]},left_arm:{P:[6.0f,-2.0f,0.0f]},right_leg:{P:[-2.0f,-12.0f,0.0f]},right_legwear:{P:[0.0f,-6.0f,0.0f]},anchor:{P:[0.0f,16.0f,0.0f],C:16777215},left_armwear:{P:[0.0f,-4.0f,0.0f]}}},Settings:{Hands:1b},Name:\"blockbuster."+slim+"\"}");
          uiContext.get("char").morph(m_new);
        }
        else
        {
          states.setString("slim_type", "fred");
          var skin = states.getString("skin");
          var slim = states.getString("slim_type");
          suit_skin = "b.a:image/skins/steve_suit.png";
          var m_new = mappet.createMorph("{Animation:{Interp:21,Animates:1b},Skin:[{Path:\""+ skin +"\"},{Path:\"blockbuster:textures/entity/skin_masks/bodywear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_legwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_legwear.png\",Erase:1b},{Path:\""+suit_skin+"\"}],CustomPose:{Size:[0.6f,1.8f,0.6f],Poses:{right_arm:{P:[-6.0f,-2.0f,0.0f]},left_leg:{P:[2.0f,-12.0f,0.0f]},right_armwear:{P:[0.0f,-4.0f,0.0f]},outer:{P:[0.0f,4.0f,0.0f]},left_legwear:{P:[0.0f,-6.0f,0.0f]},body:{P:[0.0f,8.0f,0.0f]},bodywear:{P:[0.0f,-6.0f,0.0f]},head:{P:[0.0f,8.0f,0.0f]},left_arm:{P:[6.0f,-2.0f,0.0f]},right_leg:{P:[-2.0f,-12.0f,0.0f]},right_legwear:{P:[0.0f,-6.0f,0.0f]},anchor:{P:[0.0f,16.0f,0.0f],C:16777215},left_armwear:{P:[0.0f,-4.0f,0.0f]}}},Settings:{Hands:1b},Name:\"blockbuster."+slim+"\"}");
          uiContext.get("char").morph(m_new);
        }
        
    }

    if (uiContext.getLast() === "skin_apply")
    {
        states.setString("skin", data.getString("textbox"));
        //skin var
        var skin = states.getString("skin");
        var slim = states.getString("slim_type");
        
    if (slim_type == "alex")
    {
        suit_skin = "b.a:image/skins/alex_suit.png";
    }
    else if (slim_type == "fred")
    {
        suit_skin = "b.a:image/skins/steve_suit.png";
    }
        
        var m_new = mappet.createMorph("{Animation:{Interp:21,Animates:1b},Skin:[{Path:\""+ skin +"\"},{Path:\"blockbuster:textures/entity/skin_masks/bodywear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_legwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_legwear.png\",Erase:1b},{Path:\""+suit_skin+"\"}],CustomPose:{Size:[0.6f,1.8f,0.6f],Poses:{right_arm:{P:[-6.0f,-2.0f,0.0f]},left_leg:{P:[2.0f,-12.0f,0.0f]},right_armwear:{P:[0.0f,-4.0f,0.0f]},outer:{P:[0.0f,4.0f,0.0f]},left_legwear:{P:[0.0f,-6.0f,0.0f]},body:{P:[0.0f,8.0f,0.0f]},bodywear:{P:[0.0f,-6.0f,0.0f]},head:{P:[0.0f,8.0f,0.0f]},left_arm:{P:[6.0f,-2.0f,0.0f]},right_leg:{P:[-2.0f,-12.0f,0.0f]},right_legwear:{P:[0.0f,-6.0f,0.0f]},anchor:{P:[0.0f,16.0f,0.0f],C:16777215},left_armwear:{P:[0.0f,-4.0f,0.0f]}}},Settings:{Hands:1b},Name:\"blockbuster."+slim+"\"}");
        uiContext.get("char").morph(m_new);
        c.getSubject().setMorph(m_new);
    }
    
    if (uiContext.getLast() === "exit")
    {
        s.closeUI();
    }
}