function main(c)
{
//light
c.executeCommand("/light 0");
c.executeCommand("/gamemode 3 @a");
c.executeCommand("/clear @a");

//packs_respawn 
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 3), -969, 22, -1613);
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 3), -972, 22, -1644);
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 5), -990, 22, -1654);
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 2), -1007, 16, -1645);
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 2), -1007, 22, -1643);
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 2), -1016, 22, -1636);
       //room
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 4), -1020, 22, -1630);
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 3), -1030, 22, -1633);
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 4), -1026, 22, -1637);
       //
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 3), -1030, 22, -1628);
       //
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 2), -1017, 22, -1620);
       //storage
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 5), -1011, 22, -1610);
       //
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 3), -1002, 22, -1626);
       //
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 3), -997, 22, -1618);
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 4), -975, 22, -1617);
       //
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 3), -994, 22, -1609);
       //med
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 4), -981, 22, -1633);
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 5), -990, 22, -1624);
       //
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 5), -1032, 22, -1636);
       //
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 4), -1002, 21, -1640);
       c.getWorld().setBlock(mappet.createBlockState("ifc:pack_full", 4), -975, 21, -1605);
       
//syringebox_clear
     c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -998, 21, -1622);
     c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1010, 21, -1629);
     c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1005, 21, -1653);
     c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -964, 21, -1622);
     c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1019, 21, -1612);
     c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -985, 22, -1629);
       
//gates
      //gate1
      c.executeCommand("/modelblock morph -963 23 -1630 {Animation:{Interp:21,Animates:1b,Duration:20},Skin:\"b.a:infctd_gates/skins/gates.png\",CustomPose:{Size:[1.0f,1.0f,1.0f],Poses:{door2:{},door1:{}}},Settings:{Hands:1b},Name:\"blockbuster.infctd_gates\"}");
      c.getWorld().setBlock(mappet.createBlockState("ifc:keypad", 4), -964, 22, -1632);
      c.executeCommand("/fill -963 22 -1631 -963 21 -1629 minecraft:barrier");
      c.executeCommand("/fill -964 24 -1631 -964 24 -1629 ifc:lamp2 4");
      //gate2
      c.executeCommand("/modelblock morph -1017 23 -1607 {Animation:{Interp:21,Animates:1b,Duration:20},Skin:\"b.a:infctd_gates/skins/gates.png\",CustomPose:{Size:[1.0f,1.0f,1.0f],Poses:{door2:{},door1:{}}},Settings:{Hands:1b},Name:\"blockbuster.infctd_gates\"}");
      c.getWorld().setBlock(mappet.createBlockState("ifc:keypad", 2), -1015, 22, -1608);
      c.executeCommand("/fill -1016 22 -1607 -1018 21 -1607 barrier");
      c.executeCommand("/fill -1016 24 -1608 -1018 24 -1608 ifc:lamp2");
      
//remove all notes
      c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1005, 22, -1613);
      c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -971, 22, -1627);
      c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -985, 22, -1622);
      c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1008, 22, -1637);
      c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1020, 22, -1631);
      
//remove checkers
         c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1006, 22, -1616);
         c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -973, 22, -1621);
         c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1018, 17, -1653);
         c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1035, 22, -1641);
         c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -987, 22, -1632);
      
//despawn_npc
     c.executeCommand("/mp npc despawn @e");
     c.executeCommand("/effect @a clear");
      
var players = c.getServer().getAllPlayers();

//set_players
c.executeCommand("/mp state set @a infected 0");
c.executeCommand("/mp state set @a jerk 0");
c.executeCommand("/mp state set @a packs 0");
c.executeCommand("/mp state set @a werewolf 0")
c.executeCommand("/mp state set @a status death");
c.executeCommand("/mp state set @a votekill 0");
c.executeCommand("/mp state set @a vote_speaked 0");
c.executeCommand("/mp hud close @a pack");
c.executeCommand("/effect @a minecraft:weakness 999999 0 true")
//set_7_players
c.executeCommand("/mp state set @r[mpe=status==\"death\"] status alive") //1
c.executeCommand("/mp state set @r[mpe=status==\"death\"] status alive") //2
c.executeCommand("/mp state set @r[mpe=status==\"death\"] status alive") //3
c.executeCommand("/mp state set @r[mpe=status==\"death\"] status alive") //4
c.executeCommand("/mp state set @r[mpe=status==\"death\"] status alive") //5
c.executeCommand("/mp state set @r[mpe=status==\"death\"] status alive") //6
c.executeCommand("/mp state set @r[mpe=status==\"death\"] status alive") //7
//set_infected
c.executeCommand("/mp state set @r[mpe=status==\"alive\",name=!nickname] infected 1") //infected TEST
c.executeCommand("/mp state set @r[mpe=status==\"alive\",mpe=infected==0] jerk 1") //jerk
c.executeCommand("/mp hud setup @a time");

c.getServer().getStates().setNumber("players_alive", 0);

//set_AlivePlayers
for (var i in players)
 {
  if (players[i].getStates().getString("status") == "alive")
  {
    c.getServer().getStates().add("players_alive", 1);
    
          //Became human morph
          var skin = players[i].getStates().getString("skin");
          var slim_type = players[i].getStates().getString("slim_type");
          var suit_skin;
    
          if (slim_type == "alex")
          {
           suit_skin = "b.a:image/skins/alex_suit.png";
          }
           if (slim_type == "fred")
          {
           suit_skin = "b.a:image/skins/steve_suit.png";
          }
          
          var morph = mappet.createMorph("{Animation:{Interp:21,Animates:1b},Skin:[{Path:\""+ skin +"\"},{Path:\"blockbuster:textures/entity/skin_masks/bodywear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_legwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_legwear.png\",Erase:1b},{Path:\""+suit_skin+"\"}],CustomPose:{Size:[0.6f,1.8f,0.6f],Poses:{right_arm:{P:[-6.0f,-2.0f,0.0f]},left_leg:{P:[2.0f,-12.0f,0.0f]},right_armwear:{P:[0.0f,-4.0f,0.0f]},outer:{P:[0.0f,4.0f,0.0f]},left_legwear:{P:[0.0f,-6.0f,0.0f]},body:{P:[0.0f,8.0f,0.0f]},bodywear:{P:[0.0f,-6.0f,0.0f]},head:{P:[0.0f,8.0f,0.0f]},left_arm:{P:[6.0f,-2.0f,0.0f]},right_leg:{P:[-2.0f,-12.0f,0.0f]},right_legwear:{P:[0.0f,-6.0f,0.0f]},anchor:{P:[0.0f,16.0f,0.0f],C:16777215},left_armwear:{P:[0.0f,-4.0f,0.0f]}}},Settings:{Hands:1b},Name:\"blockbuster."+slim_type+"\"}");
          players[i].setMorph(morph);
  }
 }

//set_ServerVariables
c.getServer().getStates().setNumber("time", 5);
c.getServer().getStates().setNumber("in_game", 1);
c.getServer().getStates().setNumber("light_on", 0);
c.getServer().getStates().setNumber("distributors", 30);
c.getServer().getStates().setNumber("stage", 0);
c.getServer().getStates().setNumber("tasks", 0);
c.getServer().getStates().setNumber("time_freeze", 0);
c.getServer().getStates().setNumber("can_vote", 0);
c.getServer().getStates().setNumber("checker_spawn", 0);
c.getServer().getStates().setNumber("syringe_spawn", 0);

//despawn_all_items
c.executeCommand("/mp script exec @r random_stage");

c.executeCommand("/effect @a minecraft:instant_health 1 50");
c.executeCommand("/effect @a minecraft:saturation 1 50");
c.executeCommand("/difficulty 0");


c.executeCommand("/playsound mp.sounds:infctd.gameplay.5sec neutral @a -982 10000 -1634 10000000 1");

c.executeCommand("/gamemode 2 @a[mpe=status==\"alive\"]");

c.executeCommand("/mp hud setup @a transition");

  c.scheduleScript(13, function (context)
  {
//TeleportAlivePlayers
c.executeCommand("/tp @a[mpe=status==\"alive\"] -996 27 -1638");
c.executeCommand("/tp @r[x=-996,y=27,z=-1638,r=3,mpe=status==\"alive\"] -1036 21 -1641 -30 -80");
c.executeCommand("/tp @r[x=-996,y=27,z=-1638,r=3,mpe=status==\"alive\"] -976 21 -1624 90 -90");
c.executeCommand("/tp @r[x=-996,y=27,z=-1638,r=3,mpe=status==\"alive\"] -978 21 -1613 0 -90");
c.executeCommand("/tp @r[x=-996,y=27,z=-1638,r=3,mpe=status==\"alive\"] -991 21 -1650 -90 -90");
c.executeCommand("/tp @r[x=-996,y=27,z=-1638,r=3,mpe=status==\"alive\"] -998 21 -1622 180 -90");
c.executeCommand("/tp @r[x=-996,y=27,z=-1638,r=3,mpe=status==\"alive\"] -1005 21 -1643 130 -90");
c.executeCommand("/tp @r[x=-996,y=27,z=-1638,r=3,mpe=status==\"alive\"] -1013 21 -1608 130 -90");
  });
  
  
  c.scheduleScript(120, function (context)
  {
//RolesCheck
c.executeCommand("/mp hud setup @a stage_next");

//innocent
c.executeCommand("/mp hud morph @a[mpe=status==\"alive\"] stage_next 0 {Background:1879048192,Label:\"   \u0422\u042b - [b\u041d\u0415\u0412\u0418\u041d\u041e\u0412\u041d\u042b\u0419   \",Name:\"label\"}");
c.executeCommand("/mp hud morph @a[mpe=status==\"alive\"] stage_next 1 {Background:1879048192,Label:\"\u0412\u044b\u043f\u043e\u043b\u043d\u044f\u0439 [e\u0437\u0430\u0434\u0430\u043d\u0438\u044f[f, \u0447\u0442\u043e\u0431\u044b [a\u0441\u0431\u0435\u0436\u0430\u0442\u044c\",Name:\"label\"}");

//monster
c.executeCommand("/mp hud morph @a[mpe=infected==1] stage_next 0 {Background:1879048192,Label:\"   \u0422\u042b - [c\u0417\u0410\u0420\u0410\u0416\u0401\u041d\u041d\u042b\u0419   \",Name:\"label\"}");
c.executeCommand("/mp hud morph @a[mpe=infected==1] stage_next 1 {Background:1879048192,Label:\"\u041d\u0435 \u043f\u0440\u0438\u0432\u043b\u0435\u043a\u0430\u0439 [e\u0432\u043d\u0438\u043c\u0430\u043d\u0438\u0435 [f\u0438 \u043d\u0435 \u043f\u043e\u0437\u0432\u043e\u043b\u044c \u0438\u0433\u0440\u043e\u043a\u0430\u043c [c\u0441\u0431\u0435\u0436\u0430\u0442\u044c[f.\",Name:\"label\"}");
//c.executeCommand("/title @a[mpe=infected==1] actionbar [\"\",{\"text\":\"\u0422\u0432\u043e\u0439 \u0441\u043e\u043e\u0431\u0449\u043d\u0438\u043a: \"},{\"selector\":\"@a[mpe=jerk==1]\",\"color\":\"red\"}]");

//jerk
//c.executeCommand("/mp hud morph @a[mpe=jerk==1] stage_next 0 {Background:1879048192,Label:\"   \u0422\u042b - [c\u0421\u041e\u041e\u0411\u0429\u041d\u0418\u041a   \",Name:\"label\"}");
//c.executeCommand("/mp hud morph @a[mpe=jerk==1] stage_next 1 {Background:1879048192,Label:\"\u041f\u043e\u043c\u043e\u0433\u0430\u0439 [c\u0437\u0430\u0440\u0430\u0436\u0451\u043d\u043d\u043e\u043c\u0443 [f\u0438 [e\u043c\u0435\u0448\u0430\u0439 [f\u0438\u0433\u0440\u043e\u043a\u0430\u043c.\",Name:\"label\"}");

//give pack hud to infected
c.executeCommand("/mp hud setup @a[mpe=infected==1] pack");
  });
  
//SpawnDaggerCases
c.executeCommand("/setblock -1005 22 -1644 ifc:casedaggercloseempty 4");
c.executeCommand("/setblock -1012 17 -1654 ifc:casedaggercloseempty 3");
c.executeCommand("/setblock -1008 22 -1620 ifc:casedaggercloseempty 2");
c.executeCommand("/setblock -982 22 -1613 ifc:casedaggercloseempty 4");
c.executeCommand("/setblock -993 22 -1630 ifc:casedaggercloseempty 3");
c.executeCommand("/setblock -969 22 -1643 ifc:casedaggercloseempty 4");
c.executeCommand("/setblock -997 22 -1612 ifc:casedaggercloseempty 4");
c.executeCommand("/setblock -1009 22 -1641 ifc:casedaggercloseempty 3");

min = 1
max = 9
var random = Math.floor(Math.random() * (max - min) + min);

if (random == 1)
{
  c.executeCommand("/setblock -1005 22 -1644 ifc:casedaggerclose 4");
}
else if (random == 2)
{
  c.executeCommand("/setblock -1012 17 -1654 ifc:casedaggerclose 3");
}
else if (random == 3)
{
  c.executeCommand("/setblock -1008 22 -1620 ifc:casedaggerclose 2");
}
else if (random == 4)
{
  c.executeCommand("/setblock -982 22 -1613 ifc:casedaggerclose 4");
}
else if (random == 5)
{
  c.executeCommand("/setblock -993 22 -1630 ifc:casedaggerclose 3");
}
else if (random == 6)
{
  c.executeCommand("/setblock -969 22 -1643 ifc:casedaggerclose 4");
}
else if (random == 7)
{
  c.executeCommand("/setblock -997 22 -1612 ifc:casedaggerclose 4");
}
else if (random == 8)
{
  c.executeCommand("/setblock -1009 22 -1641 ifc:casedaggerclose 3");
}

c.executeCommand("/mp npc summon chair default -989 21 -1618");
c.executeCommand("/mp npc summon chair default -1027 21 -1631");
c.executeCommand("/mp npc summon chair default -1033 21 -1636");
c.executeCommand("/mp npc summon chair default -1004 21 -1611");




}