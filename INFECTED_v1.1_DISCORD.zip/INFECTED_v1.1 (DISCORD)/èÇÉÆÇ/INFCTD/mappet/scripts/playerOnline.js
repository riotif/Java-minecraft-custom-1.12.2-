function main(c) {
    var players = c.getServer().getAllPlayers();
    var inGame = c.getServer().getStates().getNumber("in_game");

    c.getServer().getStates().setNumber('players_online', players.length)

    if (c.getServer().getStates().getNumber('start_vote') >= c.getServer().getStates().getNumber('players_online')) {
        if (inGame > 0) {
            c.executeCommand('/mp script exec @r game_end');
            c.getServer().getStates().setNumber('start_vote', 0);
            c.executeCommand('/mp state clear @a start_vote');
        } else {
            c.executeCommand('/mp script exec @r game_start');
            c.getServer().getStates().setNumber('start_vote', 0)
            c.executeCommand('/mp state clear @a start_vote');
        }
    }
}