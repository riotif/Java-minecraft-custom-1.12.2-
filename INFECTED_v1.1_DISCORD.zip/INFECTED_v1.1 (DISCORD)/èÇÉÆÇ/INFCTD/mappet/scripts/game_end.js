function main(c)
{
    // Code...
    var s = c.getSubject();
    c.getServer().getStates().setNumber("in_game", 0);
    c.getServer().getStates().setNumber("time_freeze", 1);
      
        c.scheduleScript(50, function (context)
        {//schedule close HUD
        c.executeCommand("/mp hud close @a");
        c.executeCommand("/light 1");
        });


    var players = c.getServer().getAllPlayers();
    for (var i in players)
    {
    var player = players[i];
    player.closeUI();
    //unmute alive players start
    var status = player.getStates().getString("status")
    c.executeCommand("/voicemute unmute "+player.getName()+"");
    }
    
c.executeCommand("/mp hud setup @a transition");

  c.scheduleScript(13, function (context)
  {
c.executeCommand("/tp @a -996 28 -1628");
c.executeCommand("gamemode 2 @a");
  });
  
  c.executeCommand("/mp npc summon chair default -999 27 -1626");

}