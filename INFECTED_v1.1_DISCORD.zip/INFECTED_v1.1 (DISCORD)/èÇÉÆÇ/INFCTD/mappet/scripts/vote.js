function main(c)
{
    var result = c.getSubject().rayTrace(3);
    var s = c.getSubject();
    var in_game = c.getServer().getStates().getNumber("in_game");
    var vote_time = c.getServer().getStates().getNumber("vote_time");
    var votes = s.getStates().getNumber("votes");

    if (result.getEntity().getStates().getString("status") == "alive")
    {
        if (in_game == 1 && vote_time > 0)
        {
            if(votes > 0)
            {
             s.getStates().setNumber("votes", 0);
             s.setupHUD("textbar");
             var hud_morph = mappet.createMorph("{Background:-2147483648,Label:\"\u0412\u044b\u0431\u0440\u0430\u043d \u0438\u0433\u0440\u043e\u043a: [c"+result.getEntity().getName()+"\",Name:\"label\"}");
             s.changeHUDMorph("textbar", 0, hud_morph);
             c.executeCommand("/playsound mp.sounds:infctd.ui.click ambient @s ~ ~ ~ 0.3 2");
             result.getEntity().getStates().add("votekill", 1);
            }
            else
            {
             s.setupHUD("textbar");
             var hud_morph = mappet.createMorph("{Background:-2147483648,Label:\"\u0411\u043e\u043b\u044c\u0448\u0435 [c\u043d\u0435\u043b\u044c\u0437\u044f [f\u0433\u043e\u043b\u043e\u0441\u043e\u0432\u0430\u0442\u044c.\",Name:\"label\"}");
             s.changeHUDMorph("textbar", 0, hud_morph);
             c.executeCommand("/playsound mp.sounds:infctd.ui.fail ambient @s ~ ~ ~ 0.3 1.8");
            }
        }
    }
}