function main(c)
{
    // Code...
    var s = c.getSubject();
    var pos = s.getPosition();
    
    if (s.getStates().getNumber("infected") == 1)
    {
     s.sendActionBar("You can't escape'");
    }
    else
    {
     c.getWorld().playSound("mp.sounds:infctd.gameplay.player_exit", pos.x, pos.y, pos.z, 1, 2);
     s.getStates().setString("status", "death");
     c.getServer().getStates().add("players_alive", -1);
     c.executeCommand("/voicemute mute "+ s.getName());
     c.executeCommand("/playsound mp.sounds:infctd.gameplay.player_exit ambient @s ~ ~100000 ~ 100000");
     s.setGameMode(3);
    }
    
    //end_game
    var players_alive =  c.getServer().getStates().getNumber("players_alive");
    if (players_alive < 2)
    {
        c.getServer().getStates().setNumber("time_freeze", 1);
        c.getServer().getStates().setNumber("in_game", 0);
        
        c.scheduleScript(100, function (context)
        {//schedule exit game
        c.executeCommand("/mp script exec @r game_end");
        });
    }
    
}