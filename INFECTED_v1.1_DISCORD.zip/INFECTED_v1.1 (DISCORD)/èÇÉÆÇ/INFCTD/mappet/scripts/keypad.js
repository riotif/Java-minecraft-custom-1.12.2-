function main(c)
{
    var s = c.getSubject();
    var pos = s.getPosition();
    
    var ui = mappet.createUI(c, "handler").background().closable(false);
    var layout = ui.layout();
        layout.getCurrent().rxy(0.5, 0.5).wh(100, 100).anchor(0.5);
    var background = layout.graphics().id("background");
    var window = layout.graphics().id("window");
    var textfield = layout.textbox().id("textfield").tooltip("\u041f\u043e\u043b\u0435 \u0434\u043b\u044f \u0432\u0432\u043e\u0434\u0430 \u043a\u043e\u0434\u0430:").maxLength(5);
    var enter = layout.button("\u041f\u0440\u0438\u043d\u044f\u0442\u044c").id("enter");
    //Terminal name
    var title = layout.label("\u041a\u043e\u0434\u043e\u0432\u0430\u044f \u043f\u0430\u043d\u0435\u043b\u044c").id("title");
    //Task text
    var task = layout.label("\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u043a\u043e\u0434:").id("task");

    background.rxy(0.5, 0.5).wh(100, 100).anchor(0.5);
    background.rect(0, 0, 100, 100, 0x88000000);
    window.rxy(0.5, 0).wh(100, 15).anchor(0.5);
    window.rect(0, 0, 100, 15, 0x8800ffff);
    textfield.rxy(0.5, 0.57).wh(50, 20).anchor(0.5);
    enter.rxy(0.5, 0.8).wh(50, 20).anchor(0.5);
    title.rx(0.5).ry(0.025).wh(160, 20).anchor(0.5).labelAnchor(0.5);
    task.rx(0.5).ry(0.3).wh(160, 20).anchor(0.5).labelAnchor(0.5);
    
        s.openUI(ui);
        //sound
        c.getWorld().playSound("mp.sounds:infctd.ui.enter", pos.x, pos.y, pos.z, 0.2, 1.5);
        
}
function handler(c)
{
    var s = c.getSubject();
    var uiContext = c.getSubject().getUIContext();
    var data = uiContext.getData();
    var code = c.getServer().getStates().getNumber("code_exit");
    var pos = s.getPosition();
    var gates = c.getServer().getStates().getNumber("gates_num");
    


    if (uiContext.getLast() == "enter")
    {
        if (data.getString("textfield") == code)
        {
            s.swingArm();
            c.getServer().getStates().setNumber("time_exit", 10);
            
            //sound
            c.getWorld().playSound("mp.sounds:infctd.ui.success", pos.x, pos.y, pos.z, 0.3, 0.5);
            
             //close UI to every player
              var players = c.getServer().getAllPlayers();
              for (var i in players)
              {
              var player = players[i];
              player.closeUI();
              }
            
            if (gates == 1)
            {
                c.getWorld().setBlock(mappet.createBlockState("ifc:keypad_success", 4), -964, 22, -1632);
                c.executeCommand("/fill -1015 22 -1608 -1015 22 -1608 ifc:keypad 2 replace ifc:keypad_on");
                c.executeCommand("/playsound mp.sounds:infctd.gameplay.gates_preparing neutral @a -963 22 -1630 2 1");
                
            }
            else if (gates == 2)
            {
                c.getWorld().setBlock(mappet.createBlockState("ifc:keypad_success", 2), -1015, 22, -1608);
                c.executeCommand("/fill -964 22 -1632 -964 22 -1632 ifc:keypad 4 replace ifc:keypad_on");
                c.executeCommand("/playsound mp.sounds:infctd.gameplay.gates_preparing neutral @a -1017 22 -1607 2 1");
                
            }
        }
        else
        {
            s.closeUI();
            s.swingArm();
            
            //sound
            c.getWorld().playSound("mp.sounds:infctd.ui.fail", pos.x, pos.y, pos.z, 0.5, 0.4);
        }
    }
}