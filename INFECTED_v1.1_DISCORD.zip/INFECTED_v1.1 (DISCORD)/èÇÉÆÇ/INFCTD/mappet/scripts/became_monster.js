function main(c)
{
    // Code...
    var s = c.getSubject();
    var infected = s.getStates().getNumber("infected");
    var morph_blocked = s.getStates().getNumber("morph_blocked");
    var werewolf = s.getStates().getNumber("werewolf");
    var packs = s.getStates().getNumber("packs");
    var light = c.getServer().getStates().getNumber("light_on");
    var time = c.getServer().getStates().getNumber("time");
    var pos = s.getPosition();
    
if (infected == 1 && morph_blocked == 0)
{
    if (infected == 1 && light == 0)
    {

        
      if (werewolf == 0)
      {
          if (packs >= 1 && time > 1)
          {
             //Became Monster
             s.getStates().setNumber("werewolf", 1);
             
             var monster_morph = mappet.createMorph("{Pose:{Pose:{jaw:{},Eyes:{G:1.0f},left_leg:{},right_arm:{},left_legBOTTOM:{},left_armBOTTOM:{},right_armBOTTOM:{},Tail4:{},jaw_up:{},Tail1:{},BodyTOP:{},right_ear:{},BodyBOTTOM:{},Tail3:{},left_ear:{},Tail2:{},head:{},right_feet:{},right_feet2:{},right_leg:{},left_arm:{},root:{},right_legBOTTOM:{}}},Skin:\"c.s:werewolf/skins/werewolf.png\",Name:\"chameleon.werewolf\"}");
             
             //morph sound
             c.getWorld().playSound("mp.sounds:infctd.monster.monster_morph", pos.x, pos.y, pos.z, 0.5, 1.2);
             
             //Particles
             var smoke = mappet.getParticleType("smoke");
             var explode = mappet.getParticleType("largesmoke");
             var pos = s.getPosition();

             c.getWorld().spawnParticles(smoke, false, pos.x, pos.y+1, pos.z, 30, 0.2, 0.3, 0.2, 0.1);
             c.getWorld().spawnParticles(explode, false, pos.x, pos.y+1, pos.z, 15, 0.3, 0.3, 0.3, 0.1);
             //Particles end
             
             //night vision
             c.executeCommand("/effect @a[mpe=infected==1] minecraft:night_vision 100 0 true");
             c.executeCommand("/effect @a[mpe=infected==1] minecraft:strength 30 10 true");
             
             s.setMorph(monster_morph);
             
          }
          else
          {
           //HUD_toInfected
           c.executeCommand("/mp hud setup @a[mpe=infected==1] textbar");
           c.executeCommand("/mp hud morph @a[mpe=infected==1] textbar 0 {Background:-2147483648,Label:\" \u041d\u0435\u0434\u043e\u0441\u0442\u0430\u0442\u043e\u0447\u043d\u043e [b\u0436\u0438\u0434\u043a\u043e\u0441\u0442\u0438[f... \",Name:\"label\"}");
          }
      }
      else
      {   
             //Particles demorph
             var smoke = mappet.getParticleType("smoke");
             var explode = mappet.getParticleType("largesmoke");
             var pos = s.getPosition();

             c.getWorld().spawnParticles(smoke, false, pos.x, pos.y+1, pos.z, 30, 0.2, 0.3, 0.2, 0);
             c.getWorld().spawnParticles(explode, false, pos.x, pos.y+1, pos.z, 15, 0.3, 0.3, 0.3, 0);
             //Particles demorph end
      
          //Became human morph
          var skin = s.getStates().getString("skin");
          var slim_type = s.getStates().getString("slim_type");
          var suit_skin;
    
          if (slim_type == "alex")
          {
           suit_skin = "b.a:image/skins/alex_suit.png";
          }
           if (slim_type == "fred")
          {
           suit_skin = "b.a:image/skins/steve_suit.png";
          }
          
          var morph = mappet.createMorph("{Animation:{Interp:21,Animates:1b},Skin:[{Path:\""+ skin +"\"},{Path:\"blockbuster:textures/entity/skin_masks/bodywear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_legwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_legwear.png\",Erase:1b},{Path:\""+suit_skin+"\"}],CustomPose:{Size:[0.6f,1.8f,0.6f],Poses:{right_arm:{P:[-6.0f,-2.0f,0.0f]},left_leg:{P:[2.0f,-12.0f,0.0f]},right_armwear:{P:[0.0f,-4.0f,0.0f]},outer:{P:[0.0f,4.0f,0.0f]},left_legwear:{P:[0.0f,-6.0f,0.0f]},body:{P:[0.0f,8.0f,0.0f]},bodywear:{P:[0.0f,-6.0f,0.0f]},head:{P:[0.0f,8.0f,0.0f]},left_arm:{P:[6.0f,-2.0f,0.0f]},right_leg:{P:[-2.0f,-12.0f,0.0f]},right_legwear:{P:[0.0f,-6.0f,0.0f]},anchor:{P:[0.0f,16.0f,0.0f],C:16777215},left_armwear:{P:[0.0f,-4.0f,0.0f]}}},Settings:{Hands:1b},Name:\"blockbuster."+slim_type+"\"}");
          s.setMorph(morph);
          
          s.getStates().setNumber("werewolf", 0);
          //demorph sound
          c.getWorld().playSound("mp.sounds:infctd.monster.monster_demorph", pos.x, pos.y, pos.z, 0.5, 0.8);
          
          //night vision close
          c.executeCommand("/effect @a[mpe=infected==1] minecraft:night_vision 0");
          c.executeCommand("/effect @a[mpe=infected==1] minecraft:strength 0");
          
          if (packs > 20)
          {
              s.getStates().setNumber("packs", 20);
          }
          else if (packs > 10 && packs < 20)
          {
              s.getStates().setNumber("packs", 10);
          }
          else if (packs > 0 && packs < 10)
          {
              s.getStates().setNumber("packs", 0);
          }
          
            var packs_new = s.getStates().getNumber("packs");
            morph_hud = mappet.createMorph("{Top:90,Bottom:"+packs_new * 3+",Animation:{Interp:3,Animates:1b},Texture:\"b.a:image/skins/packbar_main.png\",Name:\"blockbuster.image\"}");
            s.changeHUDMorph("pack", 1, morph_hud);
       }
    }
    else if (infected == 1 && light == 1)
    {
        s.sendActionBar("\u041f\u043e\u043a\u0430 \u0435\u0449\u0451 \u0441\u0432\u0435\u0442\u043b\u043e...");
    }
}    
else if (infected == 1 && morph_blocked == 1)
{
             s.setupHUD("textbar");
             var hud_morph = mappet.createMorph("{Background:-2147483648,Label:\" \u0422\u044b [c\u043d\u0435 \u043c\u043e\u0436\u0435\u0448\u044c [f\u043e\u0431\u0440\u0430\u0442\u0438\u0442\u044c\u0441\u044f \u043d\u0430 \u044d\u0442\u043e\u0439 [e\u0441\u0442\u0430\u0434\u0438\u0438[f. \",Name:\"label\"}");
             s.changeHUDMorph("textbar", 0, hud_morph);
             c.executeCommand("/playsound mp.sounds:infctd.ui.fail ambient @s ~ ~ ~ 0.3 0.5");
}
    
}