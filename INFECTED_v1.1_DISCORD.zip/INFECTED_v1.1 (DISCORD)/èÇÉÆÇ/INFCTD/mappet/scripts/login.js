function main(c)
{
    var s = c.getSubject();
    var login = s.getStates().getString("Login");
    var ui = mappet.createUI(c, "handler").background().closable(true);
    var layout = ui.layout();
    layout.getCurrent().rxy(0.5, 0.5).wh(100, 100).anchor(0.5);
    c.executeCommand("/gamemode 3 @s")
    c.executeCommand("/mp hud setup @s transition");
    c.executeCommand("/mp hud setup @s light_close");
    c.executeCommand("/tp @s -1018 20 -1646 -55 -15");
    
    if (login == "")
    {
        var text = layout.label("\u0421\u043e\u0437\u0434\u0430\u0439\u0442\u0435 [a\u043f\u0430\u0440\u043e\u043b\u044c[f.").id("text").background(0x88000000);
        var textbox = layout.textbox().id("register").tooltip("\u041f\u043e\u043b\u0435 \u0434\u043b\u044f \u043f\u0430\u0440\u043e\u043b\u044f").visible(true);
        var button = layout.button("\u0421\u043e\u0437\u0434\u0430\u0442\u044c").id("set").visible(true);
    }
    else
    {
        var text = layout.label("\u0412\u0432\u0435\u0434\u0438\u0442\u0435 [a\u043f\u0430\u0440\u043e\u043b\u044c[f.").id("text").background(0x88000000);
        var textbox = layout.textbox().id("login").tooltip("\u041f\u043e\u043b\u0435 \u0434\u043b\u044f \u043f\u0430\u0440\u043e\u043b\u044f").visible(true);
        var button = layout.button("\u0412\u0432\u0435\u0441\u0442\u0438").id("enter").visible(true);
    }
    
    text.rx(0.465).ry(0.33).wh(20, 20).anchor(0.5).labelAnchor(0.5);
    textbox.rxy(0.5, 0.5).wh(100, 20).anchor(0.5);
    button.rxy(0.5, 0.73).wh(100, 20).anchor(0.5);
    
    //Open UI
    c.getSubject().openUI(ui);
}

function handler(c)
{
    var s = c.getSubject();
    var login = s.getStates().getString("Login");
    var uiContext = s.getUIContext();
    var data = uiContext.getData();

    if (uiContext.getLast() === "enter")
    {
        if (data.getString("login") === login)
        {
           s.closeUI();
           s.sendActionBar("\u041f\u0440\u0438\u044f\u0442\u043d\u043e\u0439 \u0438\u0433\u0440\u044b!")
           s.setupHUD("time");
           c.executeCommand("/tp @s @r");
           
           var in_game = c.getServer().getStates().getNumber("in_game");
           if (in_game > 0)
           {
               c.executeCommand("/voicemute mute "+s.getName()+"");
           }
           else
           {
               c.executeCommand("/voicemute unmute "+s.getName()+"");
           }
        }
        else
        {
          uiContext.get("text").label("\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 [c\u043f\u0430\u0440\u043e\u043b\u044c[f.");
          uiContext.get("login").label("");
        }
    }
    
        if (uiContext.getLast() === "set")
    {
        if (data.getString("register") === "")
        {
           uiContext.get("text").label("\u041d\u0435\u043b\u044c\u0437\u044f \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c [c\u043f\u0443\u0441\u0442\u043e\u0439 [f\u043f\u0430\u0440\u043e\u043b\u044c.");
        }
        else
        {
           s.getStates().setString("Login", data.getString("register"));
           s.closeUI();
           s.sendActionBar("\u041f\u0430\u0440\u043e\u043b\u044c \u0441\u043e\u0437\u0434\u0430\u043d, \u043f\u0440\u0438\u044f\u0442\u043d\u043e\u0439 \u0438\u0433\u0440\u044b!");
           s.setupHUD("time");
           c.executeCommand("/tp @s @r");
    //skin       
    c.scheduleScript(5, function (context)
    {
     c.executeCommand("/mp script exec @s skin");
    });
           
           var in_game = c.getServer().getStates().getNumber("in_game");
           if (in_game > 0)
           {
               c.executeCommand("/voicemute mute "+s.getName()+"");
           }
           else
           {
               c.executeCommand("/voicemute unmute "+s.getName()+"");
           }
        }
    }
    
    
}