function main(c) {
    var s = c.getSubject();
    if (s.getStates().getString("start_vote") == "voted") {
        s.getStates().setString("start_vote", "no_voted");
        c.getServer().getStates().add("start_vote", -1);
    }
}