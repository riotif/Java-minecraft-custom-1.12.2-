function main(c) {
    var inGame = c.getServer().getStates().getNumber("in_game");
    players = c.getServer().getStates().getNumber("players_online");
    playersVote = c.getServer().getStates().getNumber("start_vote");
    ui = mappet.createUI(c, "handler").background();
    var layout = ui.layout();
        layout.getCurrent().rxy(0.5, 0.5).wh(160, 80).anchor(0.5);
    graphic = layout.graphics().rxy(0.5, 0.5).wh(160, 80).anchor(0.5).id("background");
  
    if (inGame > 0) {
        if (c.getSubject().getStates().getString("start_vote") != "voted") {
            var endGame = layout.button("Закончить "+ playersVote +"/"+ players).id("button");
        } else { 
            var endGame = layout.button("Закончить "+ playersVote +"/"+ players).id("button").enabled(false);
        }
            var endGameLabel = layout.label("Завершить игру.").id("task");
            changeSkin = layout.button("Изменить облик").id("skin").enabled(false);
      
    } else { 
        if (c.getSubject().getStates().getString("start_vote") != "voted") {
            var endGame = layout.button("Играть "+ playersVote +"/"+ players).id("button");
        } else { 
            var endGame = layout.button("Играть "+ playersVote +"/"+ players).id("button").enabled(false);
        } 
      endGameLabel = layout.label("Начать игру").id("task");
      changeSkin = layout.button("Изменить облик").id("skin"); 
    }
    
    endGame.rxy(0.5, 0.4).wh(100, 20).anchor(0.5); 
    changeSkin.rxy(0.5, 0.7).wh(100, 20).anchor(0.5);
    endGameLabel.rx(0.5).ry(0.15).wh(160, 20).anchor(0.5).labelAnchor(0.5);
    graphic.rect(0, 0, 160, 80, 2281701376); 
    
    c.getSubject().openUI(ui);
  }
  function handler(c) {
    var UIContext = c.getSubject().getUIContext(); 
    inGame = c.getServer().getStates().getNumber("in_game");
    if (UIContext.getLast() === "button") {
      c.getServer().getStates().add("start_vote", 1);
      c.getSubject().getStates().setString("start_vote", "voted");
    }
    UIContext.getLast() === "skin" && c.scheduleScript(4, function (keighan) {
      c.executeCommand("/mp script exec @s skin");
    }),
    c.getSubject().closeUI();
  }