function rand(a, b)
{
    return Math.random() * (b - a) + a;
}

function main(c)
{
    var s = c.getSubject();
    var min = 1;
    var max = 11;
    var random_a = Math.floor(rand(min, max));
    s.getStates().setNumber("result", random_a);
    var pos = s.getPosition();

    var ui = mappet.createUI(c, "handler").background().closable(false);
    var layout = ui.layout();
        layout.getCurrent().rxy(0.5, 0.5).wh(200, 100).anchor(0.5);
    var background = layout.graphics().id("background");
    var backdrop = layout.graphics().id("window");
    var window = layout.graphics().id("window");
    var enter = layout.button("\u041f\u0440\u0438\u043d\u044f\u0442\u044c").id("enter");
    var random = layout.button("\u0441\u043b\u0443\u0447.").id("random");
    //Terminal name
    var title = layout.label("\u0422\u0435\u0440\u043c\u0438\u043d\u0430\u043b").id("title");
    //Task text
    var task = layout.label("\u0412\u044b\u0432\u0435\u0434\u0438\u0442\u0435 \u0447\u0438\u0441\u043b\u043e: [a"+random_a+"").id("task");
    var number = layout.label("0").id("number");

    background.rxy(0.5, 0.5).wh(200, 100).anchor(0.5);
    background.rect(0, 0, 200, 100, 0x88000000);
    window.rxy(0.5, 0).wh(200, 15).anchor(0.5);
    window.rect(0, 0, 200, 15, 0x8800ffff);
    backdrop.rxy(0.5, 0.55).wh(50, 20).anchor(0.5);
    backdrop.rect(0, 0, 50, 20, 0x2effffff);
    enter.rxy(0.5, 0.8).wh(50, 20).anchor(0.5);
    random.rxy(0.55, 0.55).wh(30, 20).anchor(0.5);
    title.rx(0.5).ry(0.025).wh(160, 20).anchor(0.5).labelAnchor(0.5);
    task.rx(0.5).ry(0.25).wh(160, 20).anchor(0.5).labelAnchor(0.5);
    number.rx(0.43).ry(0.565).wh(160, 20).anchor(0.5).labelAnchor(0.5);
    
    if (c.getServer().getStates().getNumber("terminal4_cooldown") == 0)
    {
        s.openUI(ui);
        c.getServer().getStates().add("terminal4_cooldown", 15);
        c.getWorld().playSound("mp.sounds:infctd.ui.enter", pos.x, pos.y, pos.z, 0.2, 1);
    }
    else
    {
        c.getWorld().playSound("mp.sounds:infctd.ui.fail", pos.x, pos.y, pos.z, 0.3, 1);
        s.setupHUD("cooldown");
    }
}

function handler(c)
{
    var s = c.getSubject();
    var uiContext = c.getSubject().getUIContext();
    var data = uiContext.getData();
    var result = s.getStates().getNumber("result");
    var min = 1;
    var max = 11;
    var random_number = Math.floor(rand(min, max));
    var value = s.getStates().getNumber("t_value");
    var pos = s.getPosition();

    if (uiContext.getLast() == "enter")
    {
        if (result == value)
        {
            s.closeUI();
            c.getServer().getStates().add("tasks", 1);
            s.swingArm();
            //replace all terminal4 positions
            c.executeCommand("/fill -997 22 -1635 -997 22 -1635 ifc:terminal4_off 2 replace ifc:terminal4");
            c.executeCommand("/fill -998 22 -1626 -998 22 -1626 ifc:terminal4_off 3 replace ifc:terminal4");
            c.executeCommand("/fill -969 22 -1618 -969 22 -1618 ifc:terminal4_off 4 replace ifc:terminal4");
            
            c.getWorld().playSound("mp.sounds:infctd.ui.success", pos.x, pos.y, pos.z, 0.5, 1);
            
        //taskHUD
          var tasks_hud = c.getServer().getStates().getNumber("tasks");
          s.setupHUD("tasks");
          morph_tasks = mappet.createMorph("{Background:-2147483648,Label:\"\u0417\u0430\u0434\u0430\u0447\u0438: [e"+ tasks_hud +" [f/ 5\",Name:\"label\"}")
          s.changeHUDMorph("tasks", 0, morph_tasks);
            
        }
        else
        {
            s.closeUI();
            c.getServer().getStates().add("terminal4_cooldown", 1);
            s.swingArm();
            c.getWorld().playSound("mp.sounds:infctd.ui.fail", pos.x, pos.y, pos.z, 0.5, 0.8);
            s.setupHUD("cooldown");
        }
    }
    if (uiContext.getLast() == "random")
    {
        s.getStates().setNumber("t_value", random_number);
        var pressed = s.getStates().getNumber("t_value");
        
        uiContext.get("number").label(""+pressed+"");
        s.swingArm();
        c.getWorld().playSound("mp.sounds:infctd.ui.click", pos.x, pos.y, pos.z, 0.3, 1);
    }
}