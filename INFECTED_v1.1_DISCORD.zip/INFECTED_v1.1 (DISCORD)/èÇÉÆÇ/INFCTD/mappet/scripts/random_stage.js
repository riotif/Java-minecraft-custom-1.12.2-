function main(c)
{
    var light = c.getServer().getStates().getNumber("light_on");
    var stage = c.getServer().getStates().getNumber("stage");
    var players_alive = c.getServer().getStates().getNumber("players_alive");
    
    if (light == 0)
    {
       //remove all terminal1
       c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1018, 22, -1632);
       c.getWorld().setBlock(mappet.createBlockState("ifc:bricks2", 0), -1019, 22, -1632);
       c.getWorld().setBlock(mappet.createBlockState("ifc:bricks2", 0), -1019, 21, -1632);
       
       c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1017, 17, -1648);
       
       c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 2), -977, 22, -1615);
       c.getWorld().setBlock(mappet.createBlockState("ifc:plate4", 2), -977, 22, -1614);
       //end
         //remove all terminal2
         c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -980, 22, -1650);
         c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1004, 22, -1612);
         c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -983, 22, -1633);
         //end
           //remove all terminal3
           c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -990, 22, -1618);
           c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -971, 22, -1632);
           c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1026, 22, -1630);
           //end
             //remove all terminal4
             c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -997, 22, -1635);
             c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -998, 22, -1626);
             c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -969, 22, -1618);
             //end
               //remove all tablet
               c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1017, 22, -1618);
               c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -983, 21, -1609);
               c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1020, 22, -1631);
               c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1011, 21, -1652);
               c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -981, 21, -1654);
               //end
       //set_DISTRIBUTORS
       c.getWorld().setBlock(mappet.createBlockState("ifc:distributor", 4), -1006, 21, -1638);
       c.getWorld().setBlock(mappet.createBlockState("ifc:distributor", 5), -1002, 21, -1612);
       c.getWorld().setBlock(mappet.createBlockState("ifc:distributor", 3), -972, 21, -1630);
                //set_votekill_off
                c.getWorld().setBlock(mappet.createBlockState("ifc:votekill_off", 5), -995, 22, -1613);
                c.getWorld().setBlock(mappet.createBlockState("ifc:votekill_off", 2), -1031, 22, -1626);
                c.getWorld().setBlock(mappet.createBlockState("ifc:votekill_off", 5), -1018, 22, -1642);
                
       //effect
       c.executeCommand("/effect @a minecraft:slowness 0");
               
               
    }

if (light == 1 && stage < 7)
{

    min = 1;
    max = 4;

//terminal1 spawn points  //////////////////////////////
var random = Math.floor(Math.random() * (max - min) + min);

    if (random == 1)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:terminal1", 5), -1018, 22, -1632);
      c.getWorld().setBlock(mappet.createBlockState("ifc:plate3", 0), -1019, 22, -1632);
      c.getWorld().setBlock(mappet.createBlockState("ifc:plate3", 0), -1019, 21, -1632);
    }
    else if (random == 2)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:terminal1", 2), -1017, 17, -1648);
    }
    else if (random == 3)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:terminal1", 2), -977, 22, -1615);
      c.getWorld().setBlock(mappet.createBlockState("ifc:plate3", 2), -977, 22, -1614);
    }
    
//terminal2 spawn points //////////////////////////////
      random = Math.floor(Math.random() * (max - min) + min);
      
    if (random == 1)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:terminal2", 4), -980, 22, -1650);
    }
    else if (random == 2)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:terminal2", 4), -1004, 22, -1612);
    }
    else if (random == 3)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:terminal2", 3), -983, 22, -1633);
    }
//terminal3 spawn points //////////////////////////////
      random = Math.floor(Math.random() * (max - min) + min);
      
    if (random == 1)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:terminal3", 5), -990, 22, -1618);
    }
    else if (random == 2)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:terminal3", 2), -971, 22, -1632);
    }
    else if (random == 3)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:terminal3", 4), -1026, 22, -1630);
    }
//terminal4 spawn points //////////////////////////////
      random = Math.floor(Math.random() * (max - min) + min);
      
    if (random == 1)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:terminal4", 2), -997, 22, -1635);
    }
    else if (random == 2)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:terminal4", 3), -998, 22, -1626);
    }
    else if (random == 3)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:terminal4", 4), -969, 22, -1618);
    }
//TABLET spawn points //////////////////////////////
      min = 1;
      max = 6;
      random = Math.floor(Math.random() * (max - min) + min);
      
    if (random == 1)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:tablet", 3), -1017, 22, -1618);
    }
    else if (random == 2)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:tablet", 3), -983, 21, -1609);
    }
    else if (random == 3)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:tablet", 4), -1020, 22, -1631);
    }
    else if (random == 4)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:tablet", 4), -1011, 21, -1652);
    }
    else if (random == 5)
    {
      //place_block
      c.getWorld().setBlock(mappet.createBlockState("ifc:tablet", 4), -981, 21, -1654);
    }
    
       //set_DISTRIBUTORS
       c.getWorld().setBlock(mappet.createBlockState("ifc:distributor", 4), -1006, 21, -1638);
       c.getWorld().setBlock(mappet.createBlockState("ifc:distributor", 5), -1002, 21, -1612);
       c.getWorld().setBlock(mappet.createBlockState("ifc:distributor", 3), -972, 21, -1630);
       //effect
       c.executeCommand("/effect @a minecraft:slowness 99999 0 true");
      //voting
      c.getServer().getStates().setNumber("can_vote", 1);
      //morph_blocked
      c.executeCommand("/mp state set @a[mpe=morph_blocked==1] morph_blocked 0");
       
//doors rand
min = 1;
max = 3;
doors_case = Math.floor(Math.random() * (max - min) + min);

//doors 1
if (doors_case == 1)
{
   c.getWorld().setBlock(mappet.createBlockState("ifc:doorup", 5), -1031, 22, -1638);
   c.getWorld().setBlock(mappet.createBlockState("ifc:doordown", 5), -1031, 21, -1638);
   //
   c.getWorld().setBlock(mappet.createBlockState("ifc:doorup", 2), -999, 22, -1614);
   c.getWorld().setBlock(mappet.createBlockState("ifc:doordown", 2), -999, 21, -1614);
   //
   c.getWorld().setBlock(mappet.createBlockState("ifc:doorup_open", 3), -988, 22, -1643);
   c.getWorld().setBlock(mappet.createBlockState("ifc:doordown_open", 3), -988, 21, -1643);
   //
   c.getWorld().setBlock(mappet.createBlockState("ifc:doorup_open", 5), -1012, 22, -1624);
   c.getWorld().setBlock(mappet.createBlockState("ifc:doordown_open", 5), -1012, 21, -1624);
   
   
  min = 1;
  max = 3;
  keycard_spawn = Math.floor(Math.random() * (max - min) + min);

    if (keycard_spawn == 1)
    {
     c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -976, 21, -1637);
     c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1005, 16, -1647);
     c.getWorld().setBlock(mappet.createBlockState("ifc:keycard", 2), -1013, 22, -1610);
     c.getWorld().setBlock(mappet.createBlockState("ifc:keycard", 2), -990, 22, -1606);
     
    }
    else
    {
     c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1013, 22, -1610);
     c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -990, 22, -1606);
     c.getWorld().setBlock(mappet.createBlockState("ifc:keycard", 2), -976, 21, -1637);
     c.getWorld().setBlock(mappet.createBlockState("ifc:keycard", 2), -1005, 16, -1647);
     
    }


  
//doors 2   
}
else if (doors_case == 2)
{
   c.getWorld().setBlock(mappet.createBlockState("ifc:doorup", 3), -988, 22, -1643);
   c.getWorld().setBlock(mappet.createBlockState("ifc:doordown", 3), -988, 21, -1643);
   //
   c.getWorld().setBlock(mappet.createBlockState("ifc:doorup", 5), -1012, 22, -1624);
   c.getWorld().setBlock(mappet.createBlockState("ifc:doordown", 5), -1012, 21, -1624);
   //
   c.getWorld().setBlock(mappet.createBlockState("ifc:doorup_open", 5), -1031, 22, -1638);
   c.getWorld().setBlock(mappet.createBlockState("ifc:doordown_open", 5), -1031, 21, -1638);
   //
   c.getWorld().setBlock(mappet.createBlockState("ifc:doorup_open", 2), -999, 22, -1614);
   c.getWorld().setBlock(mappet.createBlockState("ifc:doordown_open", 2), -999, 21, -1614);
     
  min = 1;
  max = 3;
  keycard_spawn = Math.floor(Math.random() * (max - min) + min);

    if (keycard_spawn == 1)
    {
     c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1036, 21, -1635);
     c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -973, 21, -1627);
     c.getWorld().setBlock(mappet.createBlockState("ifc:keycard", 2), -1029, 22, -1633);
     c.getWorld().setBlock(mappet.createBlockState("ifc:keycard", 2), -973, 21, -1619);
     
    }
    else
    {
     c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -1029, 22, -1633);
     c.getWorld().setBlock(mappet.createBlockState("minecraft:air", 0), -973, 21, -1619);
     c.getWorld().setBlock(mappet.createBlockState("ifc:keycard", 2), -1036, 21, -1635);
     c.getWorld().setBlock(mappet.createBlockState("ifc:keycard", 2), -973, 21, -1627);
     
    }
 
}

//end
}

if (stage >= 7 && light == 1)
{    
      min = 1000;
      max = 100000;
      random = Math.floor(Math.random() * (max - min) + min);
      c.getServer().getStates().setNumber("code_exit", +random);

//notes_place

      min = 1;
      max = 6;
      random1 = Math.floor(Math.random() * (max - min) + min);
      
     if (random1 == 1)
     {
         c.getWorld().setBlock(mappet.createBlockState("ifc:note1", 4), -1005, 22, -1613);
     }
     else if (random1 == 2)
     {
         c.getWorld().setBlock(mappet.createBlockState("ifc:note1", 5), -971, 22, -1627);
     }
     else if (random1 == 3)
     {
         c.getWorld().setBlock(mappet.createBlockState("ifc:note1", 5), -985, 22, -1622);
     }
     else if (random1 == 4)
     {
         c.getWorld().setBlock(mappet.createBlockState("ifc:note1", 2), -1008, 22, -1637);
     }
     else if (random1 == 5)
     {
         c.getWorld().setBlock(mappet.createBlockState("ifc:note1", 2), -1020, 22, -1631);
     }
     
  }


if (stage == 7 && light == 0)
{
  //endless time
  c.getServer().getStates().setNumber("time_freeze", 1);
  
  c.executeCommand("/fill -1016 24 -1608 -1018 24 -1608 ifc:lamp2_nolimit");
  c.executeCommand("/fill -964 24 -1631 -964 24 -1629 ifc:lamp2_nolimit 4");
  c.getWorld().setBlock(mappet.createBlockState("ifc:keypad_on", 4), -964, 22, -1632);
  c.getWorld().setBlock(mappet.createBlockState("ifc:keypad_on", 2), -1015, 22, -1608);
  
}

if (stage == 4 && light == 1)
{
  var checker_spawn = c.getServer().getStates().getNumber("checker_spawn");
  min = 1;
  max = 6;
  random_checker = Math.floor(Math.random() * (max - min) + min);
  
  if (checker_spawn == 0)
  {
     if (random_checker == 1)
     {
         c.getWorld().setBlock(mappet.createBlockState("ifc:checkerready", 5), -1006, 22, -1616);
     }
     else if (random_checker == 2)
     {
         c.getWorld().setBlock(mappet.createBlockState("ifc:checkerready", 5), -973, 22, -1621);
     }
     else if (random_checker == 3)
     {
         c.getWorld().setBlock(mappet.createBlockState("ifc:checkerready", 5), -1018, 17, -1653);
     }
     else if (random_checker == 4)
     {
         c.getWorld().setBlock(mappet.createBlockState("ifc:checkerready", 5), -1035, 22, -1641);
     }
     else if (random_checker == 5)
     {
         c.getWorld().setBlock(mappet.createBlockState("ifc:checkerready", 5), -987, 22, -1632);
     }
     
     c.getWorld().setBlock(mappet.createBlockState("ifc:syringebox", 2), -998, 21, -1622);
     c.getWorld().setBlock(mappet.createBlockState("ifc:syringebox", 2), -1010, 21, -1629);
     c.getWorld().setBlock(mappet.createBlockState("ifc:syringebox", 3), -1005, 21, -1653);
     c.getWorld().setBlock(mappet.createBlockState("ifc:syringebox", 4), -964, 21, -1622);
     c.getWorld().setBlock(mappet.createBlockState("ifc:syringebox", 2), -1019, 21, -1612);
     c.getWorld().setBlock(mappet.createBlockState("ifc:syringebox", 5), -985, 22, -1629);
     
     //set_checker_spawn
     c.getServer().getStates().setNumber("checker_spawn", 1); 
  }
  
}

if (players_alive < 3 && light == 1)
{
c.executeCommand("/fill -1005 22 -1644 -1005 22 -1644 ifc:casedaggeropen 4 replace ifc:casedaggerclose");
c.executeCommand("/fill -1012 17 -1654 -1012 17 -1654 ifc:casedaggeropen 3 replace ifc:casedaggerclose");
c.executeCommand("/fill -1009 22 -1641 -1009 22 -1641 ifc:casedaggeropen 3 replace ifc:casedaggerclose");
c.executeCommand("/fill -993 22 -1630 -993 22 -1630 ifc:casedaggeropen 3 replace ifc:casedaggerclose");
c.executeCommand("/fill -1008 22 -1620 -1008 22 -1620 ifc:casedaggeropen 2 replace ifc:casedaggerclose");
c.executeCommand("/fill -997 22 -1612 -997 22 -1612 ifc:casedaggeropen 4 replace ifc:casedaggerclose");
c.executeCommand("/fill -969 22 -1643 -969 22 -1643 ifc:casedaggeropen 4 replace ifc:casedaggerclose");
c.executeCommand("/fill -982 22 -1613 -982 22 -1613 ifc:casedaggeropen 4 replace ifc:casedaggerclose");
}

if (light == 1)
{
  min = 1;
  max = 9;
  random_pliers = Math.floor(Math.random() * (max - min) + min);

  if (random_pliers == 1)
  {
      c.executeCommand("/setblock -1006 17 -1645 ifc:pliers 2");
  }
  else if (random_pliers == 2)
  {
      c.executeCommand("/setblock -981 21 -1618 ifc:pliers 3");
  }
  else if (random_pliers == 3)
  {
      c.executeCommand("/setblock -975 21 -1613 ifc:pliers 3")
  }
  else if (random_pliers == 4)
  {
      c.executeCommand("/setblock -978 21 -1640 ifc:pliers 5")
  }
  else if (random_pliers == 5)
  {
      c.executeCommand("/setblock -1012 22 -1635 ifc:pliers 5")
  }
  else if (random_pliers == 6)
  {
      c.executeCommand("/setblock -1008 22 -1616 ifc:pliers 4")
  }
  else if (random_pliers == 7)
  {
      c.executeCommand("/setblock -992 21 -1609 ifc:pliers 3")
  }
  else if (random_pliers == 8)
  {
      c.executeCommand("/setblock -1026 22 -1630 ifc:pliers 4")
  }
}
  
}