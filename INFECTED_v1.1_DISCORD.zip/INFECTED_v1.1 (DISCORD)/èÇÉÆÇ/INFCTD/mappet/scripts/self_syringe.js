function main(c)
{
    var s = c.getSubject();
    var item = s.getMainItem();
    var infected = s.getStates().getNumber("infected");
    
    if (item.getItem().getId() === "ifc:syringe" && infected == 1)
    {
        s.swingArm();
        s.getStates().setNumber("morph_blocked", 1);
        c.executeCommand("/clear @s ifc:syringe");
        s.setupHUD("textbar");
        var hud_morph = mappet.createMorph("{Background:-2147483648,Label:\" \u0412\u044b \u043f\u0440\u0438\u043c\u0435\u043d\u0438\u043b\u0438 [b\u0438\u043d\u044a\u0435\u043a\u0446\u0438\u044e [f\u043d\u0430 \u0441\u0435\u0431\u0435. \",Name:\"label\"}");
        s.changeHUDMorph("textbar", 0, hud_morph);
        c.executeCommand("/playsound mp.sounds:infctd.ui.fail ambient @s ~ ~ ~ 0.3 1.8");
        c.executeCommand("/playsound mp.sounds:infctd.gameplay.syringe ambient @a ~ ~ ~ 0.3 1");
    }

}