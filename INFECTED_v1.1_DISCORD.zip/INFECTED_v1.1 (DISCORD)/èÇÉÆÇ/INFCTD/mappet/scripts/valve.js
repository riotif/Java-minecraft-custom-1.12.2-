function main(c)
{
//Gets VALVE 1 rotation value
var value = c.getServer().getStates().getNumber("valve_1");

if (value >= 360)
{
    c.getServer().getStates().setNumber("valve_1", 0);
    c.executeCommand("/modelblock morph -1009 22 -1627 {Skin:\"b.a:empty/skins/texture.png\",Settings:{Hands:1b},Name:\"blockbuster.empty\"}");
    c.executeCommand("/modelblock morph -1009 22 -1627 {Animation:{Interp:21,Animates:1b},Skin:\"b.a:valve/skins/pipe.png\",CustomPose:{Size:[1.0f,1.0f,1.0f],Poses:{valve:{R:[0.0f,0.0f,"+ result +".0f]}}},Settings:{Hands:1b},Name:\"blockbuster.valve\"}");
}
else
{
    //Set STATE
    c.getServer().getStates().setNumber("valve_1", value + 45);
}

//Get NEW value of rotation
var result = c.getServer().getStates().getNumber("valve_1");

//Set modelblock rotation point
c.executeCommand("/modelblock morph -1009 22 -1627 {Animation:{Interp:21,Animates:1b},Skin:\"b.a:valve/skins/pipe.png\",CustomPose:{Size:[1.0f,1.0f,1.0f],Poses:{valve:{R:[0.0f,0.0f,"+ result +".0f]}}},Settings:{Hands:1b},Name:\"blockbuster.valve\"}");

}