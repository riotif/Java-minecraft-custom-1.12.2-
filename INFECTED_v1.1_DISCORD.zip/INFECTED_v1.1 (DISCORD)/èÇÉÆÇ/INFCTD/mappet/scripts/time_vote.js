function main(c)
{
    var in_game = c.getServer().getStates().getNumber("in_game");
    var vote_time = c.getServer().getStates().getNumber("vote_time");
    var players_speaked = c.getServer().getStates().getNumber("players_speaked");
    var players_alive = c.getServer().getStates().getNumber("players_alive");
    var players = c.getServer().getAllPlayers();
    
     if (vote_time > -1)
     {
         c.getServer().getStates().add("vote_time", -1);
         c.executeCommand("/modelblock morph -997 30 -1634 {Max:75,Lighting:0b,Label:\"0 : " + vote_time + "\",Name:\"label\"}");
     }
    if (vote_time == 3)
    {
    c.executeCommand("/playsound mp.sounds:infctd.gameplay.5sec neutral @a -996 30 -1634 0.5 2")
    }
    
    
if (in_game == 2)
{
    
    if (vote_time == 0 && players_speaked == 0)
    {
        c.getServer().getStates().setNumber("vote_time", 10);
        c.getServer().getStates().add("players_speaked", 1);
        
        for (var i in players)
        {
         if (players[i].getStates().getNumber("vote_speaked") == 1)
         {
              c.executeCommand("/modelblock morph -996 30 -1634 {Max:75,Lighting:0b,Label:\"\u0413\u043e\u0432\u043e\u0440\u0438\u0442: [b"+players[i].getName()+"\",Name:\"label\"}");
              c.executeCommand("/voicemute unmute "+players[i].getName()+"");
              c.executeCommand("/playsound mp.sounds:infctd.ui.enter neutral @a -996 30 -1634 0.5 0");
         }
        
        }
        
    }    
    else if (vote_time == 0 && players_speaked < players_alive)
    {
        c.getServer().getStates().setNumber("vote_time", 10);
        c.getServer().getStates().add("players_speaked", 1);
        
        //mute
        for (var i in players)
         {
            c.executeCommand("/voicemute mute "+players[i].getName()+"")
         }
        
        c.executeCommand("/mp state set @r[mpe=vote_speaked==0] vote_speaked 2");
        c.executeCommand("/playsound mp.sounds:infctd.ui.success neutral @a -996 30 -1634 0.5 2");
        
        //unmute
        for (var i in players)
         {
           if (players[i].getStates().getNumber("vote_speaked") == 2)
           {
               //c.send("Player: "+players[i].getName()+" speaks next!");
              c.executeCommand("/modelblock morph -996 30 -1634 {Max:75,Lighting:0b,Label:\"\u0413\u043e\u0432\u043e\u0440\u0438\u0442: [b"+players[i].getName()+"\",Name:\"label\"}");
               c.executeCommand("/voicemute unmute "+players[i].getName()+"");
               players[i].getStates().setNumber("vote_speaked", 1);
           }
         }
    }
    else if (vote_time == 0 && players_speaked == players_alive)
    {
        c.getServer().getStates().setNumber("vote_time", 15);
        c.getServer().getStates().setNumber("in_game", 1);
        //c.send("voting time:");
        c.executeCommand("/effect @a minecraft:slowness 10 3 true");
        c.executeCommand("/modelblock morph -996 30 -1634 {Max:75,Lighting:0b,Label:\"[6\u0413\u043e\u043b\u043e\u0441\u043e\u0432\u0430\u043d\u0438\u0435...\",Name:\"label\"}");
        c.executeCommand("/mp script exec @a[mpe=status==\"alive\"] voting");
        c.executeCommand("/playsound mp.sounds:infctd.ui.enter neutral @a -996 30 -1634 0.5 0");
        c.executeCommand("/mp state set @a[mpe=status==\"alive\"] votes 1");
        c.executeCommand("/mp hud setup @a[mpe=status==\"alive\"] textbar");
        c.executeCommand("/mp hud morph @a[mpe=status==\"alive\"] textbar 0 {Background:-2147483648,Label:\" [eF [f- \u0413\u043e\u043b\u043e\u0441\u043e\u0432\u0430\u0442\u044c \",Name:\"label\"}");
        
        
        //mute
        for (var i in players)
         {
            if (players[i].getStates().getString("status") == "alive")
            {
                c.executeCommand("/voicemute mute "+players[i].getName()+"")
            }
         }
    }
    
}
else if (in_game == 1)
{

    if (vote_time == 0 && players_speaked == players_alive)
    {
        c.getServer().getStates().setNumber("vote_time", 10);
        c.getServer().getStates().setNumber("players_speaked", -1);
        var died;
        
        for (var i in players)
        {
          if (players[i].getStates().getNumber("votekill") >= players_alive - 1)
          {
              died = players[i].getName();
              //c.executeCommand("/modelblock morph -996 30 -1634 {Max:75,Lighting:0b,Label:\"\u0423\u043c\u0438\u0440\u0430\u0435\u0442: [c"+players[i].getName()+"\",Name:\"label\"}");
          }
          else
          {
              //c.executeCommand("/modelblock morph -996 30 -1634 {Max:75,Lighting:0b,Label:\"\u0412\u043e\u0437\u043d\u0438\u043a\u043b\u0438 [4\u0440\u0430\u0437\u043d\u043e\u0433\u043b\u0430\u0441\u0438\u044f[f.\",Name:\"label\"}");
          }
        }
        
        if (died == null)
        {
        //noDeath
            c.executeCommand("/modelblock morph -996 30 -1634 {Max:75,Lighting:0b,Label:\"\u0412\u043e\u0437\u043d\u0438\u043a\u043b\u0438 [4\u0440\u0430\u0437\u043d\u043e\u0433\u043b\u0430\u0441\u0438\u044f[f.\",Name:\"label\"}");
            c.executeCommand("/playsound mp.sounds:infctd.ui.enter neutral @a -996 30 -1634 0.5 0");
        }
        else
        {
        //yesDeath
            c.executeCommand("/modelblock morph -996 30 -1634 {Max:75,Lighting:0b,Label:\"\u0423\u043c\u0438\u0440\u0430\u0435\u0442: [c"+died+"\",Name:\"label\"}");
            c.executeCommand("/kill "+died+"");
            c.executeCommand("/playsound mp.sounds:infctd.ui.enter neutral @a -996 30 -1634 0.5 0");
        }
        
    }
    if (vote_time == 0 && players_speaked == -1)
    {
    
         c.executeCommand("/mp hud setup @a transition");
         
         
      c.scheduleScript(13, function (context)
      {//schedule_start
      
        //tp1
        
        c.getServer().getStates().add("time", 20);
        c.getServer().getStates().setNumber("time_freeze", 0);
        c.executeCommand("/tp @a[mpe=status==\"alive\"] -996 27 -1638");
        c.executeCommand("/tp @r[x=-996,y=27,z=-1638,r=3,mpe=status==\"alive\"] -1036 21 -1641 -30 -80");
        c.executeCommand("/tp @r[x=-996,y=27,z=-1638,r=3,mpe=status==\"alive\"] -976 21 -1624 90 -90");
        c.executeCommand("/tp @r[x=-996,y=27,z=-1638,r=3,mpe=status==\"alive\"] -978 21 -1613 0 -90");
        c.executeCommand("/tp @r[x=-996,y=27,z=-1638,r=3,mpe=status==\"alive\"] -991 21 -1650 -90 -90");
        c.executeCommand("/tp @r[x=-996,y=27,z=-1638,r=3,mpe=status==\"alive\"] -998 21 -1622 180 -90");
        c.executeCommand("/tp @r[x=-996,y=27,z=-1638,r=3,mpe=status==\"alive\"] -1005 21 -1643 130 -90");
        c.executeCommand("/tp @r[x=-996,y=27,z=-1638,r=3,mpe=status==\"alive\"] -1013 21 -1608 130 -90");
        
        //unmute
        for (var i in players)
         {
            if (players[i].getStates().getString("status") == "alive")
            {
                c.executeCommand("/voicemute unmute "+players[i].getName()+"")
            }
         }
         
     });//schedule end
     
    }
     
}

}