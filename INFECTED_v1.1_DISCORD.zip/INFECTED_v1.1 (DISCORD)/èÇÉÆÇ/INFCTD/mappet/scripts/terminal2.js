function main(c) {
    min = 10, max = 99;
    var results = Math.floor(Math.random() * (max - min) + min);
    if (results % 2 === 0) {
      min = 3, max = 8;
      var t2Plus = Math.floor(Math.random() * (max - min) + min);
      while (t2Plus % 2 != 0) {t2Plus = Math.floor(Math.random() * (max - min) + min)} 
      min = 3, max = 8;
      var t2Minus = Math.floor(Math.random() * (max - min) + min);
      while (t2Minus % 2 != 0 || t2Minus == t2Plus) {t2Minus = Math.floor(Math.random() * (max - min) + min)} 
    } else {
      min = 3, max = 8;
      var t2Plus = Math.floor(Math.random() * (max - min) + min);
      while (t2Plus % 2 == 0) {t2Plus = Math.floor(Math.random() * (max - min) + min)} 
      min = 3, max = 8;
      var t2Minus = Math.floor(Math.random() * (max - min) + min);
      while (t2Minus % 2 == 0 || t2Minus == t2Plus) {t2Minus = Math.floor(Math.random() * (max - min) + min)} 
    }
    
    s = c.getSubject(), 
    pos = s.getPosition();
    s.getStates().setNumber("result", results), 
    s.getStates().setNumber("t2_plus", t2Plus), 
    s.getStates().setNumber("t2_minus", t2Minus), 
    s.getStates().setNumber("t_value", 0);
    var getT2 = s.getStates().getNumber("t2_value");
    var ui = mappet.createUI(c, "handler").background().closable(false);
    var layout = ui.layout();
        layout.getCurrent().rxy(0.5, 0.5).wh(200, 100).anchor(0.5);
    backgrounds = layout.graphics().id("background"), 
    window1 = layout.graphics().id("window"), 
    window2 = layout.graphics().id("window"), 
    enters = layout.button("Принять").id("enter"), 
    titles = layout.label("Терминал").id("title"), 
    tasks = layout.label("Составьте число: [a" + results + "").id("task"), 
    numbers = layout.label("" + getT2 + "").id("number"), 
    pluss = layout.button("+" + t2Plus + "").id("plus"), 
    minuss = layout.button("-" + t2Minus + "").id("minus");
  
    backgrounds.rxy(0.5, 0.5).wh(200, 100).anchor(0.5), 
    backgrounds.rect(0, 0, 200, 100, 2281701376), 
    window1.rxy(0.5, 0).wh(200, 15).anchor(0.5), 
    window1.rect(0, 0, 200, 15, 2281766911), 
    window2.rxy(0.5, 0.52).wh(60, 20).anchor(0.5), 
    window2.rect(0, 0, 60, 20, 3328212358), 
    enters.rxy(0.5, 0.8).wh(55, 20).anchor(0.5), 
    titles.rx(0.5).ry(0.025).wh(160, 20).anchor(0.5).labelAnchor(0.5), 
    tasks.rx(0.5).ry(0.25).wh(160, 20).anchor(0.5).labelAnchor(0.5), 
    numbers.rx(0.5).ry(0.535).wh(160, 20).anchor(0.5).labelAnchor(0.5), 
    pluss.rxy(0.7, 0.52).wh(20, 20).anchor(0.5), 
    minuss.rxy(0.3, 0.52).wh(20, 20).anchor(0.5), 
    
    c.getServer().getStates().getNumber("terminal2_cooldown") == 0 ? (s.openUI(ui), c.getServer().getStates().add("terminal2_cooldown", 15), c.getWorld().playSound("mp.sounds:infctd.ui.enter", pos.x, pos.y, pos.z, 0.2, 1)) : (c.getWorld().playSound("mp.sounds:infctd.ui.fail", pos.x, pos.y, pos.z, 0.3, 1), s.setupHUD("cooldown"));
  }
  function handler(c) {
    var s = c.getSubject(), 
    boban = s.getPosition(), 
    UIContext = c.getSubject().getUIContext(), 
    breiner = s.getStates().getNumber("result"), 
    jasuan = s.getStates().getNumber("t2_plus"), 
    lylianah = s.getStates().getNumber("t2_minus"), 
    llayla = s.getStates().getNumber("t_value");
    if (UIContext.getLast() == "plus") {
      s.getStates().add("t_value", jasuan);
      var t_values = s.getStates().getNumber("t_value");
      UIContext.get("number").label("" + t_values + ""), 
      c.getWorld().playSound("mp.sounds:infctd.ui.click", boban.x, boban.y, boban.z, 0.3, 1.2), 
      s.swingArm();
    }
    if (UIContext.getLast() == "minus") {
      s.getStates().add("t_value", -lylianah);
      var t_values = s.getStates().getNumber("t_value");
      UIContext.get("number").label("" + t_values + ""), 
      c.getWorld().playSound("mp.sounds:infctd.ui.click", boban.x, boban.y, boban.z, 0.3, 1), 
      s.swingArm();
    }
    if (UIContext.getLast() == "enter") {
      if (llayla == breiner) {
        s.swingArm(), 
        s.closeUI(), 
        c.getServer().getStates().add("tasks", 1), 
        c.executeCommand("/fill -983 22 -1633 -983 22 -1633 ifc:terminal2_off 3 replace ifc:terminal2"), 
        c.executeCommand("/fill -1004 22 -1612 -1004 22 -1612 ifc:terminal2_off 4 replace ifc:terminal2"), 
        c.executeCommand("/fill -980 22 -1650 -980 22 -1650 ifc:terminal2_off 4 replace ifc:terminal2");
  
        var naeli = c.getServer().getStates().getNumber("tasks");
  
        s.setupHUD("tasks"), 
        morph_tasks = mappet.createMorph('{Background:-2147483648,Label:"Задачи: [e' + naeli + ' [f/ 5",Name:"label"}'), 
        s.changeHUDMorph("tasks", 0, morph_tasks), 
        c.getWorld().playSound("mp.sounds:infctd.ui.success", boban.x, boban.y, boban.z, 0.4, 1);
  
      } else s.swingArm(), 
      s.closeUI(), 
      c.getServer().getStates().add("terminal2_cooldown", 15), 
      c.getWorld().playSound("mp.sounds:infctd.ui.fail", boban.x, boban.y, boban.z, 0.5, 0.8), 
      s.setupHUD("cooldown");
    }
  }