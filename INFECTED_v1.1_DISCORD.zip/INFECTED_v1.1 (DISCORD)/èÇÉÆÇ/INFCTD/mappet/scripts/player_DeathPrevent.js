function main(c)
{
    //don't forget to add this script to "Entity: hurt" event.
    damage = c.getValue("damage");
    var s = c.getSubject();
    hp = s.getHp()
    
      if (hp <= damage)
      {
        if (s.isPlayer())
        {
            c.cancel();
            
            
var in_game = c.getServer().getStates().getNumber("in_game");
var status = s.getStates().getString("status");

if (in_game > 0 && status == "alive")
{
    c.executeCommand("/mp script exec @s death");
    s.setGameMode(3);
}
else
{
    c.executeCommand("/effect @s minecraft:instant_health 1 5");
}
        }
      }
    
}