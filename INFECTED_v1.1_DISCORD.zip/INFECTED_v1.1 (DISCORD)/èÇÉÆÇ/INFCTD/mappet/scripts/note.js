function main(c)
{
    var s = c.getSubject();
    var pos = s.getPosition();
    
    var ui = mappet.createUI(c, "handler").background().closable(false);
    var layout = ui.layout();
        layout.getCurrent().rxy(0.5, 0.5).wh(100, 70).anchor(0.5);
    var background = layout.graphics().id("background");
    var window = layout.graphics().id("window");
    var exit = layout.button("\u0417\u0430\u043a\u0440\u044b\u0442\u044c").id("exit");
    //Terminal name
    var title = layout.label("\u0417\u0430\u043f\u0438\u0441\u043a\u0430").id("title");
    //Task text
    var task = layout.label("\u041d\u0443\u0436\u043d\u044b\u0439 \u043a\u043e\u0434:").id("task");
    var code = c.getServer().getStates().getNumber("code_exit");
    
    var code_num = layout.label("[e"+code+"").id("code");

    background.rxy(0.5, 0.5).wh(100, 70).anchor(0.5);
    background.rect(0, 0, 100, 70, 0x88000000);
    window.rxy(0.5, 0).wh(100, 15).anchor(0.5);
    window.rect(0, 0, 100, 15, 0x8800ffff);
    exit.rxy(0.5, 0.86).wh(50, 20).anchor(0.5);
    title.rx(0.5).ry(0.025).wh(160, 20).anchor(0.5).labelAnchor(0.5);
    task.rx(0.5).ry(0.3).wh(160, 20).anchor(0.5).labelAnchor(0.5);
    code_num.rx(0.5).ry(0.55).wh(160, 20).anchor(0.5).labelAnchor(0.5);
    
        s.openUI(ui);
        //sound
        c.getWorld().playSound("mp.sounds:infctd.gameplay.note", pos.x, pos.y, pos.z, 0.5, 1.2);
        
}
function handler(c)
{
    var s = c.getSubject();
    var uiContext = c.getSubject().getUIContext();
    var pos = s.getPosition();

    if (uiContext.getLast() == "exit")
    {
        s.closeUI();
        //sound
        c.getWorld().playSound("mp.sounds:infctd.gameplay.note", pos.x, pos.y, pos.z, 0.5, 1.5);

    }
}