function main(c)
{
    // Code...
    var s = c.getSubject();
    
    c.getSubject().setXp(0, 0);
         
     
}