function rand(_0x2992df, _0x522662) {
    return Math.random() * (_0x522662 - _0x2992df) + _0x2992df;
  }
  function main(с) {
    var s = с.getSubject();
    var _0x59c875 = Math.floor(Math.random() * 90 + 0xa);
    var _0x1b0fbc = Math.floor(Math.random() * 90 + 0xa);
    var _0x327ada = s.getPosition();
    s.getStates().setNumber("result", _0x59c875 + _0x1b0fbc);
    print(_0x59c875 + _0x1b0fbc);
    var ui = mappet.createUI(с, "handler").background().closable(false);
    var layout = ui.layout();
        layout.getCurrent().rxy(0.5, 0.5).wh(0xc8, 0x64).anchor(0.5);
    var background = layout.graphics().id("background");
    var window = layout.graphics().id("window");
    var textfield = layout.textbox().id("textfield").tooltip("Поле для ответа:").maxLength(0x3);
    var enter = layout.button("Принять").id("enter");
    var title = layout.label("Терминал").id("title");
    var task = layout.label("Выполните вычисление: [a" + _0x59c875 + " [f+ [a" + _0x1b0fbc + '').id("task");
    background.rxy(0.5, 0.5).wh(0xc8, 0x64).anchor(0.5);
    background.rect(0x0, 0x0, 0xc8, 0x64, 0x88000000);
    window.rxy(0.5, 0).wh(0xc8, 0xf).anchor(0.5);
    window.rect(0x0, 0x0, 0xc8, 0xf, 0x8800ffff);
    textfield.rxy(0.5, 0.48).wh(0x32, 0x14).anchor(0.5);
    enter.rxy(0.5, 0.70).wh(0x32, 0x14).anchor(0.5);
    title.rx(0.5).ry(0.025).wh(0xa0, 0x14).anchor(0.5).labelAnchor(0.5);
    task.rx(0.5).ry(0.25).wh(0xa0, 0x14).anchor(0.5).labelAnchor(0.5);
    if (с.getServer().getStates().getNumber("terminal1_cooldown") == 0x0) {
      s.openUI(ui);
      с.getServer().getStates().add("terminal1_cooldown", 0xf);
      с.getWorld().playSound("mp.sounds:infctd.ui.enter", _0x327ada.x, _0x327ada.y, _0x327ada.z, 0.2, 0x1);
    } else {
      с.getWorld().playSound("mp.sounds:infctd.ui.fail", _0x327ada.x, _0x327ada.y, _0x327ada.z, 0.3, 0x1);
      s.setupHUD("cooldown");
    }
  }
  function handler(_0x3f3f15) {
    var _0x30d3f4 = _0x3f3f15.getSubject();
    var _0x431ea1 = _0x3f3f15.getSubject().getUIContext();
    var _0x5ea8b5 = _0x431ea1.getData();
    var _0x4f6f4d = _0x30d3f4.getStates().getNumber("result");
    var _0x5530a0 = _0x30d3f4.getPosition();
    if (_0x431ea1.getLast() == "enter") {
      if (_0x5ea8b5.getString("textfield") == _0x4f6f4d) {
        _0x30d3f4.closeUI();
        _0x30d3f4.swingArm();
        _0x3f3f15.getServer().getStates().add("tasks", 0x1);
        _0x3f3f15.executeCommand("/fill -1018 22 -1632 -1018 22 -1632 ifc:terminal1_off 5 replace ifc:terminal1");
        _0x3f3f15.executeCommand("/fill -1017 17 -1648 -1017 17 -1648 ifc:terminal1_off 2 replace ifc:terminal1");
        _0x3f3f15.executeCommand("/fill -977 22 -1615 -977 22 -1615 ifc:terminal1_off 2 replace ifc:terminal1");
        var _0x47992c = _0x3f3f15.getServer().getStates().getNumber("tasks");
        _0x30d3f4.setupHUD("tasks");
        morph_tasks = mappet.createMorph("{Background:-2147483648,Label:\"Задачи: [e" + _0x47992c + " [f/ 5\",Name:\"label\"}");
        _0x30d3f4.changeHUDMorph("tasks", 0x0, morph_tasks);
        _0x3f3f15.getWorld().playSound("mp.sounds:infctd.ui.success", _0x5530a0.x, _0x5530a0.y, _0x5530a0.z, 0.3, 0x1);
      } else {
        _0x30d3f4.closeUI();
        _0x3f3f15.getServer().getStates().add("terminal1_cooldown", 0xf);
        _0x30d3f4.setupHUD("cooldown");
        _0x30d3f4.swingArm();
        _0x3f3f15.getWorld().playSound("mp.sounds:infctd.ui.fail", _0x5530a0.x, _0x5530a0.y, _0x5530a0.z, 0.5, 0.8);
      }
    }
  }