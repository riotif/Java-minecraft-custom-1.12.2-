function main(c)
{
    var time = c.getServer().getStates().getNumber("time");
    var time_freeze = c.getServer().getStates().getNumber("time_freeze");
    var mins = Math.floor(time/60);
    var secs = (time % 60);
    var stage = c.getServer().getStates().getNumber("stage");
    var tasks = c.getServer().getStates().getNumber("tasks");
    var light = c.getServer().getStates().getNumber("light_on");
    var players_alive = c.getServer().getStates().getNumber("players_alive");
    var in_game = c.getServer().getStates().getNumber("in_game");
     
     if (time > 0 && time_freeze == 0)
     {
         c.getServer().getStates().add("time", -1);
         morph_time = mappet.createMorph("{Background:1593835520,Max:64,Label:\"\u0421\u0442\u0430\u0434\u0438\u044f: [e"+stage+"[f/7 [7\u0412\u0440\u0435\u043c\u044f: [f"+mins+" : "+secs+"\",Name:\"label\"}");
         
         //everyPlayer...
         var players = c.getServer().getAllPlayers();
         for (var i in players)
         {
         var player = players[i];
         
         //player.sendActionBar("min: "+mins+" sec: "+secs+"");
         
         player.changeHUDMorph("time", 0, morph_time);
         
         }
         
     }
     else if (time <= 0)
     {
        //РЎС‚Р°РґРёСЏ 0
        if (light == 1)
        {
           var distributors = c.getServer().getStates().getNumber("distributors");
           
           c.getServer().getStates().setNumber("time", 40 + distributors);
           c.getServer().getStates().setNumber("light_on", 0);
           c.executeCommand("/mp event trigger @r light_off");
           c.executeCommand("/mp script exec @r random_stage");
           //distributors reset
           c.getServer().getStates().setNumber("distributors", 0);
           
            //close UI to every player
              var players = c.getServer().getAllPlayers();
              for (var i in players)
              {
              var player = players[i];
              player.closeUI();
            //mute alive players start
              var status = player.getStates().getString("status")
              
                if(status == "alive")
                {
                  c.executeCommand("/voicemute mute "+player.getName()+"");
                }
            //mute alive players end
              }
           
           //sound: power_down
           c.executeCommand("/playsound mp.sounds:infctd.gameplay.power_down neutral @a -982 1000 -1634 10000 1");
           
           //HUD_toInfected
           c.executeCommand("/mp hud setup @a[mpe=infected==1] textbar");
           c.executeCommand("/mp hud morph @a[mpe=infected==1] textbar 0 {Background:-2147483648,Label:\" [cR [f- \u0421\u043c\u0435\u043d\u0438\u0442\u044c \u0444\u043e\u0440\u043c\u0443 \",Name:\"label\"}");
         
        }
        else if (light == 0)
        {
           var distributors = c.getServer().getStates().getNumber("distributors");
        
           c.getServer().getStates().setNumber("time", (90 + distributors) - stage * 10);
           c.getServer().getStates().setNumber("light_on", 1);
           c.executeCommand("/mp event trigger @r light_on");
        
           //sound: power_down
           c.executeCommand("/playsound mp.sounds:infctd.gameplay.lights_on neutral @a -982 1000 -1634 100 1");
           
           //distributors reset
           c.getServer().getStates().setNumber("distributors", 15);
           //tasks reset
           c.getServer().getStates().setNumber("tasks", 0);
           
            //check every players
              var players = c.getServer().getAllPlayers();
              for (var i in players)
              {
                 var player = players[i];
                 //unmute alive players
                 var status = player.getStates().getString("status")
                 if(status == "alive")
                 {
                   c.executeCommand("/voicemute unmute "+player.getName()+"");
                 }
                 }
           
           
           //tasks check
           if (tasks >= 5)
           {
           
           c.executeCommand("/playsound mp.sounds:infctd.gameplay.next_stage neutral @a -982 1000 -1634 1000 1");
           c.getServer().getStates().add("stage", 1);
           
        c.scheduleScript(10, function (context)
        {//schedule
           
            //check every players
              var players = c.getServer().getAllPlayers();
              for (var i in players)
              {
              var player = players[i];
            //HUD_nextstage
            var new_stage = c.getServer().getStates().getNumber("stage");
            morph_stage_next0 = mappet.createMorph("{Background:1879048192,Label:\"   \u041d\u0430\u0441\u0442\u0443\u043f\u0438\u043b\u0430 \u0441\u0442\u0430\u0434\u0438\u044f: [e"+new_stage+"   \",Name:\"label\"}")
            morph_stage_next1 = mappet.createMorph("{Background:-2147483648,Max:150,Label:\"\u0417\u0430\u0434\u0430\u0447\u0438 \u0438\u0437 \u043f\u0440\u043e\u0448\u043b\u043e\u0439 \u0441\u0442\u0430\u0434\u0438\u0438 \u0431\u044b\u043b\u0438 [2\u0443\u0441\u043f\u0435\u0448\u043d\u043e [f\u0432\u044b\u043f\u043e\u043b\u043d\u0435\u043d\u044b.\",Name:\"label\"}")
            player.setupHUD("stage_next");
            player.changeHUDMorph("stage_next", 0, morph_stage_next0);
            player.changeHUDMorph("stage_next", 1, morph_stage_next1);
            //
           }
           
     });//schedule
        }
            c.executeCommand("/mp script exec @r random_stage");
     }
  }
     
        if (time == 5 && light == 1)
        {
         c.executeCommand("/playsound mp.sounds:infctd.gameplay.5sec neutral @a -982 10000 -1634 10000000 1")
        }
     
        if (time == 24 && light == 0)
        {
         c.executeCommand("/playsound mp.sounds:infctd.gameplay.power_up neutral @a -982 10000 -1634 10000000 1")
        }
     
     
     //terminal1_cooldown
     if (c.getServer().getStates().getNumber("terminal1_cooldown") > 0)
     {
         c.getServer().getStates().add("terminal1_cooldown", -1);
     }
     //terminal2_cooldown
     if (c.getServer().getStates().getNumber("terminal2_cooldown") > 0)
     {
         c.getServer().getStates().add("terminal2_cooldown", -1);
     }
     //terminal3_cooldown
     if (c.getServer().getStates().getNumber("terminal3_cooldown") > 0)
     {
         c.getServer().getStates().add("terminal3_cooldown", -1);
     }
     //terminal5_cooldown
     if (c.getServer().getStates().getNumber("terminal4_cooldown") > 0)
     {
         c.getServer().getStates().add("terminal4_cooldown", -1);
     }
     
//EXIT_TIME
     if (c.getServer().getStates().getNumber("time_exit") > -1)
     {
         c.getServer().getStates().add("time_exit", -1);
     }
     
     if (c.getServer().getStates().getNumber("time_exit") == 0)
     {
        var gates = c.getServer().getStates().getNumber("gates_num")
        //replace keypads
        c.executeCommand("/fill -1015 22 -1608 -1015 22 -1608 ifc:keypad_on 2 replace ifc:keypad");
        c.executeCommand("/fill -964 22 -1632 -964 22 -1632 ifc:keypad_on 4 replace ifc:keypad");
        
        if (gates == 1)
        {
            c.executeCommand("/modelblock morph -963 23 -1630 {Animation:{Interp:21,Animates:1b,Duration:20},Skin:\"b.a:infctd_gates/skins/gates.png\",CustomPose:{Size:[1.0f,1.0f,1.0f],Poses:{door2:{P:[20.0f,0.0f,0.0f]},door1:{P:[-20.0f,0.0f,0.0f]}}},Settings:{Hands:1b},Name:\"blockbuster.infctd_gates\"}");
            c.executeCommand("/playsound mp.sounds:infctd.gameplay.gates_open neutral @a -963 22 -1630 2 1");
            c.executeCommand("/fill -963 22 -1631 -963 21 -1629 air");
            
        }
        else if (gates == 2)
        {
            c.executeCommand("/modelblock morph -1017 23 -1607 {Animation:{Interp:21,Animates:1b,Duration:20},Skin:\"b.a:infctd_gates/skins/gates.png\",CustomPose:{Size:[1.0f,1.0f,1.0f],Poses:{door2:{P:[20.0f,0.0f,0.0f]},door1:{P:[-20.0f,0.0f,0.0f]}}},Settings:{Hands:1b},Name:\"blockbuster.infctd_gates\"}");
            c.executeCommand("/playsound mp.sounds:infctd.gameplay.gates_open neutral @a -1017 22 -1607 2 1");
            c.executeCommand("/fill -1016 22 -1607 -1018 21 -1607 air");
            
        }
        
     }
}