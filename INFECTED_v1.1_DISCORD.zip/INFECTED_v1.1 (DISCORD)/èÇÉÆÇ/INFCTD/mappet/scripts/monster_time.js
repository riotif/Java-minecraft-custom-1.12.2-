function main(c)
{
    if (c.getServer().getStates().getNumber("light_on") == 0)
    {
         //everyPlayer...
         var players = c.getServer().getAllPlayers();
         
         for (var i in players)
         {
         var player = players[i];
         
           if (player.getStates().getNumber("werewolf") == 1)
           {
              var time = c.getServer().getStates().getNumber("time");
              var packs = player.getStates().getNumber("packs");
              
              if (packs < 1 || time <= 1)
              {     
          //Became human morph
          var skin = player.getStates().getString("skin");
          var slim_type = player.getStates().getString("slim_type");
          var suit_skin;
    
          if (slim_type == "alex")
          {
           suit_skin = "b.a:image/skins/alex_suit.png";
          }
           if (slim_type == "fred")
          {
           suit_skin = "b.a:image/skins/steve_suit.png";
          }
          
          var morph = mappet.createMorph("{Animation:{Interp:21,Animates:1b},Skin:[{Path:\""+ skin +"\"},{Path:\"blockbuster:textures/entity/skin_masks/bodywear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_legwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_legwear.png\",Erase:1b},{Path:\""+suit_skin+"\"}],CustomPose:{Size:[0.6f,1.8f,0.6f],Poses:{right_arm:{P:[-6.0f,-2.0f,0.0f]},left_leg:{P:[2.0f,-12.0f,0.0f]},right_armwear:{P:[0.0f,-4.0f,0.0f]},outer:{P:[0.0f,4.0f,0.0f]},left_legwear:{P:[0.0f,-6.0f,0.0f]},body:{P:[0.0f,8.0f,0.0f]},bodywear:{P:[0.0f,-6.0f,0.0f]},head:{P:[0.0f,8.0f,0.0f]},left_arm:{P:[6.0f,-2.0f,0.0f]},right_leg:{P:[-2.0f,-12.0f,0.0f]},right_legwear:{P:[0.0f,-6.0f,0.0f]},anchor:{P:[0.0f,16.0f,0.0f],C:16777215},left_armwear:{P:[0.0f,-4.0f,0.0f]}}},Settings:{Hands:1b},Name:\"blockbuster."+slim_type+"\"}");
          player.setMorph(morph);
                
                player.getStates().setNumber("werewolf", 0);
                var pos = player.getPosition();
                c.executeCommand("/playsound mp.sounds:infctd.monster.monster_demorph hostile @a "+pos.x+" "+pos.y+" "+pos.z+" 0.5 1");
                c.executeCommand("/particle smoke "+pos.x+" "+(pos.y+1)+" "+pos.z+" 0.3 0.3 0.3 0 30")
                c.executeCommand("/particle largesmoke "+pos.x+" "+(pos.y+1)+" "+pos.z+" 0.3 0.3 0.3 0 15")
                //night vision close
                c.executeCommand("/effect @a[mpe=infected==1] minecraft:night_vision 0");
                c.executeCommand("/effect @a[mpe=infected==1] minecraft:strength 0");
                
                //test
                  if (packs > 20)
                  {
                      player.getStates().setNumber("packs", 20);
                  }
                  else if (packs > 10 && packs < 20)
                  {
                      player.getStates().setNumber("packs", 10);
                  }
                  else if (packs > 0 && packs < 10)
                  {
                      player.getStates().setNumber("packs", 0);
                  }
              }
              else if (packs > 0)
              {
                  player.getStates().add("packs", -1);
              }
              
                  var packs_new = player.getStates().getNumber("packs");
           
            morph_hud = mappet.createMorph("{Top:90,Bottom:"+packs_new * 3+",Animation:{Interp:3,Animates:1b},Texture:\"b.a:image/skins/packbar_main.png\",Name:\"blockbuster.image\"}");
            player.changeHUDMorph("pack", 1, morph_hud);
           }
         
         }
    } 
}