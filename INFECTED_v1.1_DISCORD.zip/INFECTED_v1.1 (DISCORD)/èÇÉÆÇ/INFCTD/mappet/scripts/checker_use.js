function main(c)
{
    var result = c.getSubject().rayTrace(3);
    var s = c.getSubject();
    var in_game = c.getServer().getStates().getNumber("in_game");
    var vote_time = c.getServer().getStates().getNumber("vote_time");
    var votes = s.getStates().getNumber("votes");
    var item = s.getMainItem();
    
    
        if (item.getItem().getId() === "ifc:checkerready" && result.isMissed())
        {
            c.executeCommand("/mp hud setup @s textbar");
            c.executeCommand("/mp hud morph @s textbar 0 {}");

            c.executeCommand("/playsound mp.sounds:infctd.gameplay.checker_load ambient @a ~ ~ ~ 1 1.5")
            s.setMainItem(mappet.createItem("ifc:checkerloading"));
            
                    c.scheduleScript(15, function (context)
                    {
                    //1
                     c.executeCommand("/playsound mp.sounds:infctd.gameplay.checker_stop ambient @a ~ ~ ~ 1 2")
                     c.executeCommand("/clear @s ifc:checkerloading");
                     s.setMainItem(mappet.createItem("ifc:checkerready"));
                    //
                    });
            
        }

    if (result.getEntity().getStates().getString("status") == "alive")
    {
        if (item.getItem().getId() === "ifc:checkerready")
        {
            if (result.getEntity().getStates().getNumber("infected") == 1 && result.getEntity().getStates().getNumber("morph_blocked") == 0)
            //infected
            {
              c.executeCommand("/playsound mp.sounds:infctd.gameplay.checker_start ambient @a ~ ~ ~ 1 1");
              c.executeCommand("/playsound mp.sounds:infctd.gameplay.checker_load ambient @a ~ ~ ~ 1 1");
              s.setMainItem(mappet.createItem("ifc:checkerloading"));
              c.executeCommand("/mp hud setup @s textbar");
              c.executeCommand("/mp hud morph @s textbar 0 {}");
            
                c.scheduleScript(20, function (context)
                {
                //1
              c.executeCommand("/playsound mp.sounds:infctd.gameplay.checker_stop ambient @a ~ ~ ~ 1 0.5");
                 c.executeCommand("/clear @s ifc:checkerloading");
                 s.setMainItem(mappet.createItem("ifc:checkerinfected"));
                //
                    c.scheduleScript(60, function (context)
                    {
                    //2
                     c.executeCommand("/clear @s ifc:checkerinfected");
                    //
                    });
                
                });
            }
            else
            //not an infected
            {
              c.executeCommand("/playsound mp.sounds:infctd.gameplay.checker_start ambient @a ~ ~ ~ 1 1");
              c.executeCommand("/playsound mp.sounds:infctd.gameplay.checker_load ambient @a ~ ~ ~ 1 1");
              s.setMainItem(mappet.createItem("ifc:checkerloading"));
              c.executeCommand("/mp hud setup @s textbar");
              c.executeCommand("/mp hud morph @s textbar 0 {}");
            
                c.scheduleScript(20, function (context)
                {
                //1
              c.executeCommand("/playsound mp.sounds:infctd.gameplay.checker_stop ambient @a ~ ~ ~ 1 1");
                 c.executeCommand("/clear @s ifc:checkerloading");
                 s.setMainItem(mappet.createItem("ifc:checkerinnocent"));
                //
                    c.scheduleScript(60, function (context)
                    {
                    //2
                     c.executeCommand("/clear @s ifc:checkerinnocent");
                    //
                    });
                
                });
            }
        }
        else if (item.getItem().getId() === "ifc:syringe")
        {
          s.swingArm();
          result.getEntity().getStates().setNumber("morph_blocked", 1);
          c.executeCommand("/clear @s ifc:syringe");
             s.setupHUD("textbar");
             var hud_morph = mappet.createMorph("{Background:-2147483648,Label:\" [c"+result.getEntity().getName()+" [f\u043d\u0435 \u0441\u043c\u043e\u0436\u0435\u0442 \u043e\u0431\u0440\u0430\u0442\u0438\u0442\u044c\u0441\u044f \u043d\u0430 \u044d\u0442\u043e\u0439 [e\u0441\u0442\u0430\u0434\u0438\u0438[f. \",Name:\"label\"}");
             s.changeHUDMorph("textbar", 0, hud_morph);
             c.executeCommand("/playsound mp.sounds:infctd.ui.fail ambient @s ~ ~ ~ 0.3 1.8");
             c.executeCommand("/playsound mp.sounds:infctd.gameplay.syringe ambient @a ~ ~ ~ 1 1");
        }
    }
}