function main(c)
{
    // Code...
    var s = c.getSubject();
    var item = s.getMainItem();
    var infected = s.getStates().getNumber("infected");
    var jerk = s.getStates().getNumber("jerk");
    var time = c.getServer().getStates().getNumber("time");
    var packs = s.getStates().getNumber("packs");
    var x = c.getValue("x");
    var y = c.getValue("y");
    var z = c.getValue("z");
    var block = c.getValue("block");
    var meta = c.getValue("meta")
    var light = c.getServer().getStates().getNumber("light_on");
    
    
    if (infected == 1)
    {
        
        if (block == "ifc:pack_full" && packs < 30)
        {
            c.getWorld().setBlock(mappet.createBlockState("ifc:pack_empty", meta), x, y, z);
            s.getStates().add("packs", 10);
            
            var packs_new = s.getStates().getNumber("packs");
            
            morph_hud = mappet.createMorph("{Top:90,Bottom:"+packs_new * 3+",Animation:{Interp:3,Animates:1b},Texture:\"b.a:image/skins/packbar_main.png\",Name:\"blockbuster.image\"}");
            s.changeHUDMorph("pack", 1, morph_hud);
            
            c.executeCommand("/playsound mp.sounds:infctd.monster.drink ambient @s ~ ~ ~");
        }
        
    }
    //coordinates pipe
    
    //pipe 1 coordinates: -1009 22 -1629
    if (block == "ifc:pipe" && x == -1009 && y == 22 && z == -1629 && c.getValue("hand") == "main")
    {
        //vlv Gets VALVE 1 rotation value
        var value = c.getServer().getStates().getNumber("valve_1");

        if (value >= 360)
        {
        c.getServer().getStates().setNumber("valve_1", 0);
        c.executeCommand("/modelblock morph -1009 22 -1627 {Skin:\"b.a:empty/skins/texture.png\",Settings:{Hands:1b},Name:\"blockbuster.empty\"}");
        c.executeCommand("/modelblock morph -1009 22 -1627 {Animation:{Interp:21,Animates:1b},Skin:\"b.a:valve/skins/pipe.png\",CustomPose:{Size:[1.0f,1.0f,1.0f],Poses:{valve:{R:[0.0f,0.0f,"+ result +".0f]}}},Settings:{Hands:1b},Name:\"blockbuster.valve\"}");
        }
        else
        {
        //vlv Set STATE
        c.getServer().getStates().setNumber("valve_1", value + 45);
        }
        //vlv Get NEW value of rotation
        s.swingArm();
        var result = c.getServer().getStates().getNumber("valve_1");
        //vlv Set modelblock rotation point
        c.executeCommand("/modelblock morph -1009 22 -1627 {Animation:{Interp:21,Animates:1b},Skin:\"b.a:valve/skins/pipe.png\",CustomPose:{Size:[1.0f,1.0f,1.0f],Poses:{valve:{R:[0.0f,0.0f,"+ result +".0f]}}},Settings:{Hands:1b},Name:\"blockbuster.valve\"}");
        //vlv ----------
    }
    
    //terminal1
    if (block == "ifc:terminal1" && c.getValue("hand") == "main")
    {
        c.executeCommand("/mp script exec @s terminal1")
    }
    //terminal2
    if (block == "ifc:terminal2" && c.getValue("hand") == "main")
    {
        c.executeCommand("/mp script exec @s terminal2")
    }
    //terminal3
    if (block == "ifc:terminal3" && c.getValue("hand") == "main")
    {
        c.executeCommand("/mp script exec @s terminal3")
    }
    //tablet
    if (block == "ifc:tablet" && c.getValue("hand") == "main")
    {
        c.executeCommand("/mp script exec @s tablet")
    }
    //terminal5
    if (block == "ifc:terminal4" && c.getValue("hand") == "main")
    {
        c.executeCommand("/mp script exec @s terminal4")
    }
    
    //note1
    if (block == "ifc:note1" && c.getValue("hand") == "main")
    {
        c.executeCommand("/mp script exec @s note")
    }
    
    //distributor PLIERS
    if (block == "ifc:distributor" || block == "ifc:distributor_on" || block == "ifc:distributor_off")
    {
        //pliers use
        if (light == 1 && c.getValue("hand") == "main" && item.getItem().getId() === "ifc:pliers")
        {
            var smoke = mappet.getParticleType("smoke");
            c.executeCommand("/clear @s ifc:pliers 0 1");
            s.swingArm();
            c.getWorld().setBlock(mappet.createBlockState("ifc:distributor_off", meta), x, y, z);
            c.getWorld().spawnParticles(smoke, true, x, y+1, z, 35, 0.5, 0.5, 0.5, 0);
            c.getWorld().playSound("mp.sounds:infctd.distributor.off", x, y, z, 0.2, 1);
            c.getWorld().playSound("minecraft:entity.zombie.attack_iron_door", x, y, z, 0.2, 1.5);
            c.getServer().getStates().setNumber("time", 0);
        }
    }
    //distributor NEUTRAL
    if (block == "ifc:distributor" && c.getValue("hand") == "main")
    {
        var smoke = mappet.getParticleType("smoke");
        //light
        if (light == 1)
        {
            if (s.isSneaking())
            {
                s.swingArm();
                c.getWorld().setBlock(mappet.createBlockState("ifc:distributor_off", meta), x, y, z);
                c.getWorld().spawnParticles(smoke, true, x, y+1, z, 35, 0.5, 0.5, 0.5, 0);
                c.getServer().getStates().add("distributors", 5);
                c.getWorld().playSound("mp.sounds:infctd.distributor.off", x, y, z, 0.2, 1);
                
                //set_votekill_off
                c.getWorld().setBlock(mappet.createBlockState("ifc:votekill_off", 5), -995, 22, -1613);
                c.getWorld().setBlock(mappet.createBlockState("ifc:votekill_off", 2), -1031, 22, -1626);
                c.getWorld().setBlock(mappet.createBlockState("ifc:votekill_off", 5), -1018, 22, -1642);
                
            }
            else
            {
               s.swingArm();
                c.getWorld().setBlock(mappet.createBlockState("ifc:distributor_on", meta), x, y, z);
                c.getServer().getStates().add("distributors", -5);
                c.getWorld().playSound("mp.sounds:infctd.distributor.on", x, y, z, 0.2, 1);
                
                //set_votekill
                c.getWorld().setBlock(mappet.createBlockState("ifc:votekill", 5), -995, 22, -1613);
                c.getWorld().setBlock(mappet.createBlockState("ifc:votekill", 2), -1031, 22, -1626);
                c.getWorld().setBlock(mappet.createBlockState("ifc:votekill", 5), -1018, 22, -1642);
            }
        }
        else
        {
            if (s.isSneaking())
            {
                s.swingArm();
                c.getWorld().setBlock(mappet.createBlockState("ifc:distributor_off", meta), x, y, z);
                c.getWorld().spawnParticles(smoke, true, x, y+1, z, 35, 0.5, 0.5, 0.5, 0);
                c.getServer().getStates().add("distributors", -15);
                c.getWorld().playSound("mp.sounds:infctd.distributor.off", x, y, z, 0.2, 1);
            }
            else
            {
                s.swingArm();
                c.getWorld().setBlock(mappet.createBlockState("ifc:distributor_on", meta), x, y, z);
                c.getServer().getStates().add("distributors", 15);
                c.getWorld().playSound("mp.sounds:infctd.distributor.on", x, y, z, 0.2, 1);
            }
        }
    }
    //distributor ON
    if (block == "ifc:distributor_on" && c.getValue("hand") == "main")
    {
        var smoke = mappet.getParticleType("smoke");
        //light
        if (light == 1)
        {
            if (s.isSneaking())
            {
                s.swingArm();
                
                c.getWorld().setBlock(mappet.createBlockState("ifc:distributor_off", meta), x, y, z);
                
                c.getWorld().spawnParticles(smoke, true, x, y+1, z, 35, 0.5, 0.5, 0.5, 0);
                c.getServer().getStates().add("distributors", 5);
                c.getWorld().playSound("mp.sounds:infctd.distributor.off", x, y, z, 0.2, 1);
                
                //set_votekill_off
                c.getWorld().setBlock(mappet.createBlockState("ifc:votekill_off", 5), -995, 22, -1613);
                c.getWorld().setBlock(mappet.createBlockState("ifc:votekill_off", 2), -1031, 22, -1626);
                c.getWorld().setBlock(mappet.createBlockState("ifc:votekill_off", 5), -1018, 22, -1642);
            }
        }
        else
        {
            if (s.isSneaking())
            {
                s.swingArm();
                c.getWorld().setBlock(mappet.createBlockState("ifc:distributor_off", meta), x, y, z);
                c.getWorld().spawnParticles(smoke, true, x, y+1, z, 35, 0.5, 0.5, 0.5, 0);
                c.getServer().getStates().add("distributors", -15);
                c.getWorld().playSound("mp.sounds:infctd.distributor.off", x, y, z, 0.2, 1);
            }
        }
    }
    //distributor OFF
    if (block == "ifc:distributor_off" && c.getValue("hand") == "main")
    {
        //light
        if (light == 1)
        {
               s.swingArm();
               c.getWorld().setBlock(mappet.createBlockState("ifc:distributor_on", meta), x, y, z);
               c.getServer().getStates().add("distributors", -5);
               c.getWorld().playSound("mp.sounds:infctd.distributor.on", x, y, z, 0.2, 1);
               
               //set_votekill
               c.getWorld().setBlock(mappet.createBlockState("ifc:votekill", 5), -995, 22, -1613);
               c.getWorld().setBlock(mappet.createBlockState("ifc:votekill", 2), -1031, 22, -1626);
               c.getWorld().setBlock(mappet.createBlockState("ifc:votekill", 5), -1018, 22, -1642);
        }
        else
        {
                s.swingArm();
                c.getWorld().setBlock(mappet.createBlockState("ifc:distributor_on", meta), x, y, z);
                c.getServer().getStates().add("distributors", 15);
                c.getWorld().playSound("mp.sounds:infctd.distributor.on", x, y, z, 0.2, 1);
        }
    }
    
    //doors
    if (block == "ifc:doorup" && c.getValue("hand") == "main")
    {
      if (item.getItem().getId() === "ifc:keycard")
      {
        s.swingArm();
        c.executeCommand("/clear @s ifc:keycard 0 1");
        c.getWorld().setBlock(mappet.createBlockState("ifc:doorup_open", meta), x, y, z);
        c.getWorld().setBlock(mappet.createBlockState("ifc:doordown_open", meta), x, y-1, z);
        c.getWorld().playSound("mp.sounds:infctd.gameplay.door_open", x, y, z, 1, 1);
      }
    }
    
    //doors close
    if (block == "ifc:doorup_open" && c.getValue("hand") == "main")
    {
      if (item.getItem().getId() === "ifc:pliers")
      {
        s.swingArm();
        c.executeCommand("/clear @s ifc:pliers 0 1");
        c.getWorld().setBlock(mappet.createBlockState("ifc:doorup", meta), x, y, z);
        c.getWorld().setBlock(mappet.createBlockState("ifc:doordown", meta), x, y-1, z);
        c.getWorld().playSound("mp.sounds:infctd.gameplay.door_open", x, y, z, 1, 0.8);
        c.getWorld().playSound("minecraft:entity.zombie.attack_iron_door", x, y, z, 1, 1.5);
      }
    }
    
//syringe_box--
    if (block == "ifc:syringebox" && c.getValue("hand") == "main")
    {
        if (item.getItem().getId() === "minecraft:air")
        {
        min = 0
        max = 100
        var drop = Math.floor(Math.random() * (max - min) + min);
        var syringe_spawn = c.getServer().getStates().getNumber("syringe_spawn");
        c.getWorld().playSound("mp.sounds:infctd.gameplay.syringe_box", x, y, z, 0.5, 1.3);
        
        if (drop <= 30 && syringe_spawn == 0)
        {
          s.swingArm();
          c.getWorld().setBlock(mappet.createBlockState("ifc:syringebox_open", meta), x, y, z);
          s.setMainItem(mappet.createItem("ifc:syringe"));
          c.executeCommand("/mp hud setup @s textbar");
          c.executeCommand("/mp hud morph @s textbar 0 {Background:-2147483648,Label:\" [eR [f- \u0418\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u044c \u043d\u0430 [c\u0438\u0433\u0440\u043e\u043a\u0435[f. \",Name:\"label\"}");
          c.getServer().getStates().setNumber("syringe_spawn", 1);
          
          if (infected == 1)
          {
            c.executeCommand("/title @s actionbar [\"\",{\"text\":\"[\",\"bold\":true,\"color\":\"yellow\"},{\"text\":\"\u041f\u041a\u041c\",\"bold\":true},{\"text\":\"] \",\"bold\":true,\"color\":\"yellow\"},{\"text\":\"\u041f\u0440\u0438\u043c\u0435\u043d\u0438\u0442\u044c \u043d\u0430 \u0441\u0435\u0431\u0435\"}]");
          }
        }
        else
        {
          s.swingArm();
          c.getWorld().setBlock(mappet.createBlockState("ifc:syringebox_open", meta), x, y, z);
        }
        
        }
    }
    
    //keycard
    if (block == "ifc:keycard" && c.getValue("hand") == "main")
    {
        if (item.getItem().getId() === "minecraft:air")
        {
          s.swingArm();
          c.getWorld().setBlock(mappet.createBlockState("minecraft:air", meta), x, y, z);
          s.setMainItem(mappet.createItem("ifc:keycard"));
          c.getWorld().playSound("mp.sounds:infctd.gameplay.keycard", x, y, z, 0.5, 1);
        }
    }
    
    //pliers
    if (block == "ifc:pliers" && c.getValue("hand") == "main")
    {
        if (item.getItem().getId() === "minecraft:air")
        {
          s.swingArm();
          c.getWorld().setBlock(mappet.createBlockState("minecraft:air", meta), x, y, z);
          s.setMainItem(mappet.createItem("ifc:pliers"));
          c.getWorld().playSound("mp.sounds:infctd.gameplay.keycard", x, y, z, 0.5, 0.5);
          c.getWorld().playSound("minecraft:block.iron_trapdoor.close", x, y, z, 0.5, 1.5);
        }
    }
    
    //ifc:casedaggeropen
    if (block == "ifc:casedaggeropen" && infected == 0 && c.getValue("hand") == "main")
    {
        if (item.getItem().getId() === "minecraft:air")
        {
          s.swingArm();
          c.getWorld().setBlock(mappet.createBlockState("ifc:casedaggeropenempty", meta), x, y, z);
          s.setMainItem(mappet.createItem("ifc:daggeritem"));
          c.getWorld().playSound("mp.sounds:infctd.gameplay.keycard", x, y, z, 1, 0.5);
          c.getWorld().playSound("minecraft:item.armor.equip_iron", x, y, z, 0.5, 1.5);
        }
    }
    
    //tablet
    if (block == "ifc:tablet" && c.getValue("hand") == "main")
    {
        s.swingArm();
        c.getWorld().setBlock(mappet.createBlockState("ifc:tablet_off", meta), x, y, z);
        c.getServer().getStates().add("tasks", 1);
        c.getWorld().playSound("mp.sounds:infctd.ui.click", x, y, z, 0.3, 1);
        c.getWorld().playSound("mp.sounds:infctd.ui.success", x, y, z, 0.3, 1);
        
        //taskHUD
          var tasks_hud = c.getServer().getStates().getNumber("tasks");
          s.setupHUD("tasks");
          morph_tasks = mappet.createMorph("{Background:-2147483648,Label:\"\u0417\u0430\u0434\u0430\u0447\u0438: [e"+ tasks_hud +" [f/ 5\",Name:\"label\"}")
          s.changeHUDMorph("tasks", 0, morph_tasks);
          
    }
    
      //locker_closed
      if (block == "ifc:lockerup" && c.getValue("hand") == "main")
      {
        if (light == 0)
        {
          s.swingArm();
          c.getWorld().setBlock(mappet.createBlockState("ifc:lockerup_open", meta), x, y, z);
          c.getWorld().setBlock(mappet.createBlockState("ifc:lockerdown_open", meta), x, y - 1, z);
          c.getWorld().playSound("ifc:locker_open", x, y, z, 0.5, 1);
        }
        else
        {
          s.swingArm();
          c.getWorld().playSound("ifc:locker_close", x, y, z, 1, 1.5);
        }
      }
      //locker_open
      if (block == "ifc:lockerup_open" && c.getValue("hand") == "main")
      {
        if (light == 0)
        {
          s.swingArm();
          c.getWorld().setBlock(mappet.createBlockState("ifc:lockerup", meta), x, y, z);
          c.getWorld().setBlock(mappet.createBlockState("ifc:lockerdown", meta), x, y - 1, z);
          c.getWorld().playSound("ifc:locker_close", x, y, z, 0.5, 1);
        }
        else
        {
          c.getWorld().playSound("ifc:locker_close", x, y, z, 1, 1.5);
        }
      }
      
//checker
      if (block == "ifc:checkerready" && c.getValue("hand") == "main")
      {
        if (item.getItem().getId() === "minecraft:air")
        {
          s.swingArm();
          c.getWorld().setBlock(mappet.createBlockState("minecraft:air", meta), x, y, z);
          s.setMainItem(mappet.createItem("ifc:checkerready"));
          c.getWorld().playSound("mp.sounds:infctd.gameplay.checker_stop", x, y, z, 1, 1.5);
          c.executeCommand("/mp hud setup @s textbar");
          c.executeCommand("/mp hud morph @s textbar 0 {Background:-2147483648,Label:\" [eR [f- \u0421\u043a\u0430\u043d\u0438\u0440\u043e\u0432\u0430\u0442\u044c\ \",Name:\"label\"}");
        }
      }
    
    
    if (block == "ifc:keypad_on" && x == -964 && y == 22 && z == -1632 && c.getValue("hand") == "main")
    {
        c.getServer().getStates().setNumber("gates_num", 1);
        c.executeCommand("/mp script exec @s keypad")
        
    }
    
    if (block == "ifc:keypad_on" && x == -1015 && y == 22 && z == -1608 && c.getValue("hand") == "main")
    {
        c.getServer().getStates().setNumber("gates_num", 2);
        c.executeCommand("/mp script exec @s keypad")
    }
    
    //votekill
    if (block == "ifc:votekill" && c.getValue("hand") == "main")
    {
    var time = c.getServer().getStates().getNumber("time");
    var stage = c.getServer().getStates().getNumber("stage");
    var can_vote = c.getServer().getStates().getNumber("can_vote");
    var players_alive = c.getServer().getStates().getNumber("players_alive");
    
     if (time > 10 && stage < 7 && players_alive > 2 && can_vote == 1)
     {
        c.executeCommand("/mp hud setup @a transition");
        c.getServer().getStates().setNumber("can_vote", 0);
        
    c.scheduleScript(13, function (context)
    {//schedule_start
        c.getWorld().setBlock(mappet.createBlockState("ifc:votekill_off", meta), x, y, z);
    c.executeCommand("/mp state set @a[mpe=status==\"alive\"] vote_speaked 0");
    c.executeCommand("/mp state set @a[mpe=status==\"death\"] vote_speaked -1");
    s.getStates().setNumber("vote_speaked", 1);
        c.getServer().getStates().setNumber("in_game", 2);
        c.getServer().getStates().setNumber("players_speaked", 0);
        c.getServer().getStates().setNumber("time_freeze", 1);
        c.getServer().getStates().setNumber("vote_time", 10);
        c.executeCommand("/modelblock morph -996 30 -1634 {Max:75,Lighting:0b,Label:\"\u041d\u0430\u0447\u0438\u043d\u0430\u0435\u0442: [e"+s.getName()+"\",Name:\"label\"}");
        c.executeCommand("/tp @a -995.9 27.5 -1636.2 0 -15");
        c.executeCommand("/playsound mp.sounds:infctd.gameplay.player_exit neutral @a -996 30 -1634 2 2");
        c.executeCommand("/playsound mp.sounds:infctd.ui.fail neutral @a -996 30 -1634 2 0");
        
    var players = c.getServer().getAllPlayers();
        for (var i in players)
         {
            c.executeCommand("/voicemute mute "+players[i].getName()+"")
            players[i].getStates().setNumber("votekill", 0);
         }
    });//schedule end
         
       }
       else 
       {
        s.sendActionBar("\u041d\u0435\u0432\u043e\u0437\u043c\u043e\u0436\u043d\u043e \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u044c.");
        c.getWorld().playSound("mp.sounds:infctd.ui.fail", x, y, z, 0.2, 0);
       }
    }
}