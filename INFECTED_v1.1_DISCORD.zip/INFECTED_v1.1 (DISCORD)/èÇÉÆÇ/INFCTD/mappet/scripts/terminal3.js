function rand(a, b)
{
    return Math.random() * (b - a) + a;
}

function main(c)
{
    var s = c.getSubject();
    var min = 10;
    var max = 100;
    var random_a = Math.floor(rand(min, max));
    var pos = s.getPosition();

    s.getStates().setNumber("result", random_a);

    var ui = mappet.createUI(c, "handler").background().closable(false);
    var layout = ui.layout();
        layout.getCurrent().rxy(0.5, 0.5).wh(200, 100).anchor(0.5);
    var background = layout.graphics().id("background");
    var backdrop = layout.graphics().id("window");
    var window = layout.graphics().id("window");
    var enter = layout.button("\u041f\u0440\u0438\u043d\u044f\u0442\u044c").id("enter");
    var plus = layout.button("+").id("plus");
    //Terminal name
    var title = layout.label("\u0422\u0435\u0440\u043c\u0438\u043d\u0430\u043b").id("title");
    //Task text
    var task = layout.label("\u0412\u044b\u0432\u0435\u0434\u0438\u0442\u0435 \u0447\u0438\u0441\u043b\u043e: [a"+random_a+"").id("task");
    var number = layout.label("0").id("number");

    background.rxy(0.5, 0.5).wh(200, 100).anchor(0.5);
    background.rect(0, 0, 200, 100, 0x88000000);
    window.rxy(0.5, 0).wh(200, 15).anchor(0.5);
    window.rect(0, 0, 200, 15, 0x8800ffff);
    backdrop.rxy(0.5, 0.55).wh(50, 20).anchor(0.5);
    backdrop.rect(0, 0, 50, 20, 0x2effffff);
    enter.rxy(0.5, 0.8).wh(50, 20).anchor(0.5);
    plus.rxy(0.575, 0.55).wh(20, 20).anchor(0.5);
    title.rx(0.5).ry(0.025).wh(160, 20).anchor(0.5).labelAnchor(0.5);
    task.rx(0.5).ry(0.25).wh(160, 20).anchor(0.5).labelAnchor(0.5);
    number.rx(0.45).ry(0.57).wh(160, 20).anchor(0.5).labelAnchor(0.5);
    
    if (c.getServer().getStates().getNumber("terminal3_cooldown") == 0)
    {
        s.openUI(ui);
        c.getServer().getStates().add("terminal3_cooldown", 15);
         c.getWorld().playSound("mp.sounds:infctd.ui.enter", pos.x, pos.y, pos.z, 0.3, 1);
    }
    else
    {
         c.getWorld().playSound("mp.sounds:infctd.ui.fail", pos.x, pos.y, pos.z, 0.3, 1);
         s.setupHUD("cooldown");
    }
}

function handler(c)
{
    var s = c.getSubject();
    var uiContext = c.getSubject().getUIContext();
    var data = uiContext.getData();
    var result = s.getStates().getNumber("result");
    var pressed = data.getInt("plus");
    var pos = s.getPosition();

    if (uiContext.getLast() == "enter")
    {
        if (pressed == result)
        {
            s.closeUI();
            c.getServer().getStates().add("tasks", 1);
         c.getWorld().playSound("mp.sounds:infctd.ui.success", pos.x, pos.y, pos.z, 0.4, 1);
            s.swingArm();
            //replace all terminal3 positions
            c.executeCommand("/fill -990 22 -1618 -990 22 -1618 ifc:terminal3_off 5 replace ifc:terminal3");
            c.executeCommand("/fill -971 22 -1632 -971 22 -1632 ifc:terminal3_off 2 replace ifc:terminal3");
            c.executeCommand("/fill -1026 22 -1630 -1026 22 -1630 ifc:terminal3_off 4 replace ifc:terminal3");
            
        //taskHUD
          var tasks_hud = c.getServer().getStates().getNumber("tasks");
          s.setupHUD("tasks");
          morph_tasks = mappet.createMorph("{Background:-2147483648,Label:\"\u0417\u0430\u0434\u0430\u0447\u0438: [e"+ tasks_hud +" [f/ 5\",Name:\"label\"}")
          s.changeHUDMorph("tasks", 0, morph_tasks);
          
        }
        else
        {
            s.closeUI();
            c.getServer().getStates().add("terminal3_cooldown", 15);
         c.getWorld().playSound("mp.sounds:infctd.ui.fail", pos.x, pos.y, pos.z, 0.4, 0.8);
            s.swingArm();
            s.setupHUD("cooldown");
        }
    }
    if (uiContext.getLast() == "plus")
    {
        uiContext.get("number").label(""+pressed+"");
         c.getWorld().playSound("mp.sounds:infctd.ui.click", pos.x, pos.y, pos.z, 0.3, 1.2);
        s.swingArm();
    }
}