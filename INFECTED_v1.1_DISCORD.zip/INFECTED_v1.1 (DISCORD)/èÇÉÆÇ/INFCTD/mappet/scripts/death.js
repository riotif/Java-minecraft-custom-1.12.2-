function main(c)
{
var s = c.getSubject();
var in_game = c.getServer().getStates().getNumber("in_game");
var status = s.getStates().getString("status");
var pitch = s.getPitch();
var yaw = s.getYaw();

if (in_game > 0 && status == "alive")
{
    // Code...
    var pos = s.getPosition();
    
    c.getWorld().playSound("mp.sounds:infctd.gameplay.player_died", pos.x, pos.y, pos.z, 1, 1);
    s.getStates().setString("status", "death");
    c.getServer().getStates().add("players_alive", -1);
    c.executeCommand("/voicemute mute "+ s.getName());
    s.setGameMode(3);
    
    
    c.executeCommand("/mp npc summon corpse");
          //human morph
          var skin = s.getStates().getString("skin");
          var slim_type = s.getStates().getString("slim_type");
          var suit_skin;
    
          if (slim_type == "alex")
          {
           suit_skin = "b.a:image/skins/alex_suit.png";
          }
           if (slim_type == "fred")
          {
           suit_skin = "b.a:image/skins/steve_suit.png";
          }
          
    var corpse = c.getServer().getEntities("@e[mpe=edited==\"false\",mpid=corpse]");
    for (var i in corpse)
    {
        corpse[i].getStates().setString("edited", "true")
        corpse[i].setRotations(pitch, yaw, yaw);
        var morphCorpse = mappet.createMorph("{Pose:\"lying\",Animation:{Interp:21,Animates:1b},Skin:[{Path:\""+ skin +"\"},{Path:\"blockbuster:textures/entity/skin_masks/bodywear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_armwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/left_legwear.png\",Erase:1b},{Path:\"blockbuster:textures/entity/skin_masks/right_legwear.png\",Erase:1b},{Path:\""+ suit_skin +"\"}],CustomPose:{Size:[0.6f,0.4f,0.2f],Poses:{right_arm:{P:[-5.5f,-2.0f,0.0f],R:[-193.0f,-110.0f,155.0f],F:1b},left_leg:{P:[2.0f,-12.0f,0.0f],R:[0.0f,3.0f,15.0f],F:1b},right_armwear:{P:[0.0f,-4.0f,0.0f]},outer:{P:[0.0f,4.0f,0.0f]},left_legwear:{P:[0.0f,-6.0f,0.0f]},body:{P:[0.0f,8.0f,0.0f]},bodywear:{P:[0.0f,-6.0f,0.0f]},head:{P:[0.0f,8.0f,0.0f],R:[-14.0f,0.0f,0.0f],F:1b},left_arm:{P:[5.5f,-2.0f,0.0f],R:[-168.0f,52.0f,-16.0f],F:1b},right_leg:{P:[-2.0f,-12.0f,0.0f],R:[-2.0f,12.0f,-9.0f],F:1b},right_legwear:{P:[0.0f,-6.0f,0.0f]},anchor:{P:[0.0f,2.0f,0.0f],R:[90.0f,0.0f,0.0f],C:16777215},left_armwear:{P:[0.0f,-4.0f,0.0f]}}},Settings:{Hands:1b},Name:\"blockbuster."+ slim_type +"\"}");
        corpse[i].setMorph(morphCorpse);
    }
         c.executeCommand("/gamemode 3 @s");
    
    //end_game
    if (s.getStates().getNumber("infected") == 1)
    {
        c.getServer().getStates().setNumber("time_freeze", 1);
        c.getServer().getStates().setNumber("in_game", 0);
        
        c.scheduleScript(100, function (context)
        {//schedule exit game
        c.executeCommand("/mp script exec @r game_end");
        });
    }
    else
    {
        var light_on = c.getServer().getStates().getNumber("light_on");
        
        if (light_on == 0)
        {
          c.executeCommand("/effect @a[mpe=infected==1,r=10] minecraft:slowness 2 3 true");
        }
    }
    
    var players_alive =  c.getServer().getStates().getNumber("players_alive");
    if (players_alive < 2)
    {
        c.getServer().getStates().setNumber("time_freeze", 1);
        c.getServer().getStates().setNumber("in_game", 0);
        
        c.scheduleScript(100, function (context)
        {//schedule exit game
        c.executeCommand("/mp script exec @r game_end");
        });
    }
}
    
}